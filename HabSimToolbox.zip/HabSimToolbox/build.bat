@echo off
REM Builds HabSimToolbox.gha. Needs the .NET SDK (https://dotnet.microsoft.com/download) and internet for NuGet.
dotnet build HabSimToolbox.csproj -c Release
if errorlevel 1 ( echo Build failed. & pause & exit /b 1 )
echo.
echo Install from %~dp0dist\net48  (copy its contents, including the "python" folder, to %%APPDATA%%\Grasshopper\Libraries\HabSimToolbox)
pause
