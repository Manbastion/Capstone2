# HabSim Toolbox (Grasshopper plugin)

Five native Grasshopper blocks in a **HabSim** tab (panel *MATLAB*) that move Grasshopper values into MATLAB `.m` files and CSV files, run MATLAB, and repeat for many iterations.

| Block | What it does |
|---|---|
| Transfer Variables MATLAB | Writes values into a `.m` file |
| Transfer Variables CSV | Updates mapped cells in a CSV |
| Run MATLAB | Runs the script and reports when it is done |
| Multi-run | Fires one trigger per iteration from an editor window |
| GUI Config | Opens the variable-linking window |

**Full instructions are in [`SETUP_GUIDE.md`](SETUP_GUIDE.md)**: requirements, build, install, a first test run, every block's inputs, wiring, multi-run, notifications and troubleshooting.

## Quick start

1. Install the .NET SDK, unzip this project, and double-click `build.bat`.
2. Close Rhino and delete any old `%APPDATA%\Grasshopper\Libraries\HabSimToolbox`.
3. Copy the **contents** of `dist\net48\` (the `.gha` and the `python` folder) into `%APPDATA%\Grasshopper\Libraries\HabSimToolbox\`. Unblock the `.gha`.
4. Start Rhino, open Grasshopper, and look for the **HabSim** tab.
5. Check `python --version` and `python -c "import tkinter"` in Command Prompt. Python 3.10+ with tkinter is needed.
6. Follow "Your first run" in `SETUP_GUIDE.md`, using a copy of your `.m` file.

Nothing is pasted into Grasshopper and no project folder is connected. The Python helper code ships inside the plugin, in the `python` folder next to the `.gha`.

## Project layout

* `src/` C# components. `PyBridge.cs` runs `python/bridge_cli.py` (JSON in, tab-separated lines out).
* `python/` the backend: transfers, multi-run, history, notifications, the Tkinter windows and `run_matlab.py`.
* `python/icons/` icons for the Tkinter windows. `icons/` holds the 24 px block icons that are embedded in the `.gha`.
* `build.bat` builds into `bin\` and collects a clean install folder in `dist\`.

## Where things are stored

* Helper code: the `python` folder beside the `.gha`.
* Settings, saved GUI configuration, multi-run state, notification log: `%USERPROFILE%\HabSim\`.
* Run history: `history.json` inside the `python` folder.
