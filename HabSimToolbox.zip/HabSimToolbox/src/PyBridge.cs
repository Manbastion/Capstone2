using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;

namespace HabSim
{
    /// <summary>Reply from bridge_cli.py: repeated "key&lt;TAB&gt;value" lines.</summary>
    public class PyReply
    {
        private readonly Dictionary<string, List<string>> _data =
            new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

        public static PyReply Parse(string text)
        {
            var reply = new PyReply();
            foreach (var raw in (text ?? "").Split('\n'))
            {
                var line = raw.TrimEnd('\r');
                if (line.Length == 0) continue;
                int tab = line.IndexOf('\t');
                string key = tab < 0 ? line : line.Substring(0, tab);
                string val = tab < 0 ? "" : Unescape(line.Substring(tab + 1));
                if (!reply._data.TryGetValue(key, out var list))
                    reply._data[key] = list = new List<string>();
                list.Add(val);
            }
            return reply;
        }

        private static string Unescape(string s)
        {
            if (s.IndexOf('\\') < 0) return s;
            var sb = new StringBuilder(s.Length);
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '\\' && i + 1 < s.Length)
                {
                    char n = s[++i];
                    sb.Append(n == 'n' ? '\n' : n == 't' ? '\t' : n);
                }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        public string Get(string key, string fallback = "") =>
            _data.TryGetValue(key, out var l) && l.Count > 0 ? l[0] : fallback;

        public bool Flag(string key) => Get(key, "0") == "1";

        public int Int(string key, int fallback = 0) =>
            int.TryParse(Get(key), NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : fallback;

        public List<string> All(string key) =>
            _data.TryGetValue(key, out var l) ? new List<string>(l) : new List<string>();
    }

    /// <summary>Runs python/bridge_cli.py and returns its reply.</summary>
    public static class PyBridge
    {
        private static string _pythonDir;

        /// <summary>Folder that holds the bundled Python backend. Normally "python" next to the
        /// .gha; also searched upwards so a .gha copied out of obj\Release\... still finds it.</summary>
        public static string PythonDir
        {
            get
            {
                if (_pythonDir != null) return _pythonDir;
                string here = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? ".";
                string dir = here;
                for (int i = 0; i < 5 && !string.IsNullOrEmpty(dir); i++)
                {
                    string candidate = Path.Combine(dir, "python");
                    if (File.Exists(Path.Combine(candidate, "bridge_cli.py")))
                        return _pythonDir = candidate;
                    dir = Path.GetDirectoryName(dir);
                }
                return Path.Combine(here, "python");   // reported in the error message
            }
        }

        public static string WorkDir
        {
            get
            {
                string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                return Path.Combine(home, "HabSim");
            }
        }

        public static string StateFile => Path.Combine(WorkDir, "multirun_state.json");

        /// <summary>Python candidates, best first. An explicit PythonExe input always wins.</summary>
        public static IEnumerable<string[]> Candidates(string pythonExe)
        {
            if (!string.IsNullOrWhiteSpace(pythonExe))
            {
                yield return new[] { pythonExe.Trim(), "" };
                yield break;
            }
            string env = Environment.GetEnvironmentVariable("HABSIM_PYTHON");
            if (!string.IsNullOrWhiteSpace(env)) yield return new[] { env.Trim(), "" };
            yield return new[] { "python", "" };
            yield return new[] { "py", "-3" };
            yield return new[] { "python3", "" };
        }

        /// <summary>Environment cleaned of Rhino's embedded-Python variables.</summary>
        public static void CleanEnvironment(ProcessStartInfo psi)
        {
            var remove = new List<string>();
            foreach (string key in psi.EnvironmentVariables.Keys)
            {
                string k = key.ToUpperInvariant();
                if (k == "PYTHONHOME" || k == "PYTHONPATH" || k == "PYTHONEXECUTABLE" ||
                    k == "PYTHONSTARTUP" || k == "PYTHONUSERBASE" || k == "PYTHONNOUSERSITE" ||
                    k == "__PYVENV_LAUNCHER__" || k == "VIRTUAL_ENV")
                    remove.Add(key);
            }
            foreach (string key in remove) psi.EnvironmentVariables.Remove(key);
        }

        /// <summary>Call one bridge command. Never throws for a normal failure: the reply
        /// then carries "error" and "status" lines.</summary>
        public static PyReply Run(string command, string jsonRequest, string pythonExe = null, int timeoutMs = 60000)
        {
            string script = Path.Combine(PythonDir, "bridge_cli.py");
            if (!File.Exists(script))
                return Fail("The Python backend was not found at " + script +
                            ". Copy the whole build folder (HabSimToolbox.gha AND the 'python' folder) into Grasshopper Libraries, " +
                            "and remove any other copy of HabSimToolbox.gha (for example under obj\\).");

            string lastProblem = "Python could not be started.";
            foreach (var cand in Candidates(pythonExe))
            {
                try
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = cand[0],
                        Arguments = (cand[1].Length > 0 ? cand[1] + " " : "") +
                                    "-I \"" + script + "\" " + command,
                        WorkingDirectory = PythonDir,
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        RedirectStandardInput = true,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        StandardOutputEncoding = Encoding.UTF8,
                        StandardErrorEncoding = Encoding.UTF8,
                    };
                    CleanEnvironment(psi);
                    psi.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";

                    using (var proc = Process.Start(psi))
                    {
                        // Read stderr asynchronously so a full pipe can never block us.
                        var err = new StringBuilder();
                        proc.ErrorDataReceived += (s, e) => { if (e.Data != null) err.AppendLine(e.Data); };
                        proc.BeginErrorReadLine();

                        var bytes = new UTF8Encoding(false).GetBytes(jsonRequest ?? "{}");
                        proc.StandardInput.BaseStream.Write(bytes, 0, bytes.Length);
                        proc.StandardInput.Close();

                        string stdout = proc.StandardOutput.ReadToEnd();
                        if (!proc.WaitForExit(timeoutMs))
                        {
                            try { proc.Kill(); } catch { }
                            return Fail("The Python backend timed out (" + command + ").");
                        }
                        proc.WaitForExit();

                        if (proc.ExitCode == 0 && stdout.Length > 0)
                            return PyReply.Parse(stdout);

                        string detail = err.ToString().Trim();
                        if (detail.Length > 1500) detail = detail.Substring(detail.Length - 1500);
                        // 9009 / empty output = the Microsoft Store 'python' stub: try the next candidate.
                        lastProblem = "Python (" + cand[0] + ") exited with code " + proc.ExitCode +
                                      (detail.Length > 0 ? ": " + detail : ". Set PythonExe to the full path of python.exe.");
                    }
                }
                catch (System.ComponentModel.Win32Exception ex)
                {
                    lastProblem = "Could not start '" + cand[0] + "': " + ex.Message;
                }
            }
            return Fail(lastProblem + " Install Python 3.10+ (with tcl/tk) or set the PythonExe input.");
        }

        private static PyReply Fail(string message) =>
            PyReply.Parse("error\t1\nstatus\tERROR: " + message.Replace("\\", "\\\\").Replace("\n", "\\n") + "\n");
    }
}
