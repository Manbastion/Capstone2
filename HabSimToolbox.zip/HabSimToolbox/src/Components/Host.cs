using System;
using System.IO;
using System.Text.RegularExpressions;
using Grasshopper.Kernel;

namespace HabSim
{
    /// <summary>Shared helpers: the active multi-run controller, UI-thread recompute, state file peeks.</summary>
    public static class HabSimHost
    {
        /// <summary>The Multi-run component that is currently driving a batch (replaces sc.sticky).</summary>
        public static GH_Component Controller;

        public static void ExpireOnUi(GH_Component component)
        {
            if (component == null) return;
            try
            {
                Rhino.RhinoApp.InvokeOnUiThread((Action)(() => component.ExpireSolution(true)));
            }
            catch { }
        }

        /// <summary>One wake-up of the controller; falls back to the given component.</summary>
        public static void WakeController(GH_Component fallback)
        {
            ExpireOnUi(Controller ?? fallback);
        }

        private static readonly Regex StatusRx =
            new Regex("^  \"status\"\\s*:\\s*\"(\\w+)\"", RegexOptions.Multiline);

        /// <summary>Top-level "status" of ~/HabSim/multirun_state.json, or "" when there is none.
        /// A cheap file read, so it can be polled without starting Python.</summary>
        public static string PeekStateStatus()
        {
            try
            {
                string path = PyBridge.StateFile;
                if (!File.Exists(path)) return "";
                string text;
                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                using (var sr = new StreamReader(fs))
                    text = sr.ReadToEnd();
                var m = StatusRx.Match(text);
                return m.Success ? m.Groups[1].Value : "";
            }
            catch { return ""; }
        }
    }

    /// <summary>Base class: shared category and request-building helpers.</summary>
    public abstract class HabSimComponent : GH_Component
    {
        protected HabSimComponent(string name, string nick, string description)
            : base(name, nick, description, "HabSim", "MATLAB") { }

        protected void Error(string message) =>
            AddRuntimeMessage(GH_RuntimeMessageLevel.Error, message);

        protected void Warn(string message) =>
            AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, message);
    }
}
