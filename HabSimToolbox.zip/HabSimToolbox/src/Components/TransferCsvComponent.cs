using System;
using System.Collections.Generic;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

namespace HabSim
{
    public class TransferCsvComponent : HabSimComponent
    {
        public TransferCsvComponent()
            : base("Transfer Variables CSV", "ToCSV",
                   "Updates mapped cells in a CSV file when TriggerIn is true. " +
                   "Mapping lines: variable | identifier column | identifier | column to change. " +
                   "The CSV is modified in place - back it up first.") { }

        public override Guid ComponentGuid => new Guid("0b3f5c8e-7a41-4d6b-8d0a-1f2a3b4c5d04");
        protected override System.Drawing.Bitmap Icon => HabSimIcons.Csv;
        public override GH_Exposure Exposure => GH_Exposure.secondary;

        protected override void RegisterInputParams(GH_InputParamManager p)
        {
            p.AddTextParameter("Names", "Names", "Variable names.", GH_ParamAccess.list);
            p.AddGenericParameter("Values", "Values", "Values, one branch per variable.", GH_ParamAccess.tree);
            p.AddTextParameter("CSVFile", "CSVFile", "CSV file to update.", GH_ParamAccess.item);
            p.AddTextParameter("Mapping", "Mapping", "One mapping rule per item.", GH_ParamAccess.list);
            p.AddBooleanParameter("TriggerIn", "TriggerIn", "Transfer Variables MATLAB's Trigger.", GH_ParamAccess.item);
            p.AddTextParameter("PythonExe", "PythonExe", "Optional full path to python.exe.", GH_ParamAccess.item);
            for (int i = 0; i < p.ParamCount; i++) p[i].Optional = true;
        }

        protected override void RegisterOutputParams(GH_OutputParamManager p)
        {
            p.AddBooleanParameter("Trigger", "Trigger", "True after a successful CSV update. Connect to Run MATLAB.", GH_ParamAccess.item);
            p.AddTextParameter("Report", "Report", "What was (or would be) changed.", GH_ParamAccess.list);
            p.AddTextParameter("Status", "Status", "Status message.", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            bool trigger = false;
            DA.GetData(4, ref trigger);

            string csv = null, python = null;
            DA.GetData(2, ref csv);
            DA.GetData(5, ref python);

            // Nothing to check yet and nothing to do: stay quiet.
            if (!trigger && string.IsNullOrWhiteSpace(csv))
            {
                DA.SetData(0, false);
                DA.SetData(2, "Waiting for Trigger.");
                return;
            }

            var names = new List<string>();
            var mapping = new List<string>();
            GH_Structure<IGH_Goo> tree;
            DA.GetDataList(0, names);
            DA.GetDataTree(1, out tree);
            DA.GetDataList(3, mapping);

            var w = new JsonWriter().BeginObject();
            w.Key("names"); GhJson.StringList(w, names);
            w.Key("values").Raw(GhJson.Tree(tree));
            w.Prop("csv_file", csv ?? "");
            w.Key("mapping"); GhJson.StringList(w, mapping);
            w.Prop("trigger", trigger);
            w.EndObject();

            var reply = PyBridge.Run("transfer-csv", w.ToString(), python, 120000);
            bool error = reply.Flag("error");
            string status = reply.Get("status");

            DA.SetData(0, !error && reply.Flag("trigger"));
            DA.SetDataList(1, reply.All("report"));
            DA.SetData(2, status);

            if (error)
            {
                Error(status);
                if (trigger) HabSimHost.ExpireOnUi(HabSimHost.Controller);
            }
        }
    }
}
