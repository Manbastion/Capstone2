using System;
using System.Collections.Generic;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

namespace HabSim
{
    public class TransferMatlabComponent : HabSimComponent
    {
        public TransferMatlabComponent()
            : base("Transfer Variables MATLAB", "ToMATLAB",
                   "Writes Grasshopper values into a MATLAB .m file when TriggerIn is true. " +
                   "The .m file is modified in place - back it up first.") { }

        public override Guid ComponentGuid => new Guid("0b3f5c8e-7a41-4d6b-8d0a-1f2a3b4c5d03");
        protected override System.Drawing.Bitmap Icon => HabSimIcons.Matlab;
        public override GH_Exposure Exposure => GH_Exposure.primary;

        protected override void RegisterInputParams(GH_InputParamManager p)
        {
            p.AddTextParameter("Names", "Names", "Variable names.", GH_ParamAccess.list);
            p.AddGenericParameter("Values", "Values", "Values, one branch per variable.", GH_ParamAccess.tree);
            p.AddTextParameter("MatlabFile", "MatlabFile", "MATLAB .m file to update.", GH_ParamAccess.item);
            p.AddTextParameter("Config", "Config", "Optional: GUI Config's Config output.", GH_ParamAccess.item);
            p.AddBooleanParameter("TriggerIn", "TriggerIn", "Button, or Multi-run's Trigger.", GH_ParamAccess.item);
            p.AddTextParameter("PythonExe", "PythonExe", "Optional full path to python.exe.", GH_ParamAccess.item);
            for (int i = 0; i < p.ParamCount; i++) p[i].Optional = true;
        }

        protected override void RegisterOutputParams(GH_OutputParamManager p)
        {
            p.AddBooleanParameter("Trigger", "Trigger", "True after a successful transfer. Connect to Run MATLAB.", GH_ParamAccess.item);
            p.AddTextParameter("Report", "Report", "What was changed.", GH_ParamAccess.list);
            p.AddTextParameter("Status", "Status", "Status message.", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            bool trigger = false;
            DA.GetData(4, ref trigger);
            if (!trigger)
            {
                DA.SetData(0, false);
                DA.SetData(2, "Waiting for Trigger.");
                return;
            }

            var names = new List<string>();
            GH_Structure<IGH_Goo> tree;
            string matlabFile = null, config = null, python = null;
            DA.GetDataList(0, names);
            DA.GetDataTree(1, out tree);
            DA.GetData(2, ref matlabFile);
            DA.GetData(3, ref config);
            DA.GetData(5, ref python);

            var w = new JsonWriter().BeginObject();
            w.Key("names"); GhJson.StringList(w, names);
            w.Key("values").Raw(GhJson.Tree(tree));
            w.Prop("matlab_file", matlabFile ?? "");
            if (!string.IsNullOrWhiteSpace(config)) w.Prop("config", config);
            w.EndObject();

            var reply = PyBridge.Run("transfer-matlab", w.ToString(), python, 120000);
            bool ok = reply.Flag("trigger");
            string status = reply.Get("status");

            DA.SetData(0, ok);
            DA.SetDataList(1, reply.All("report"));
            DA.SetData(2, status);

            if (!ok)
            {
                Error(status);
                // A failed transfer aborts a running batch; wake the controller so it shows why.
                HabSimHost.ExpireOnUi(HabSimHost.Controller);
            }
        }
    }
}
