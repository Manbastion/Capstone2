using System;
using System.Collections.Generic;
using System.IO;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

namespace HabSim
{
    public class GuiConfigComponent : HabSimComponent
    {
        private bool _wasOpen;

        public GuiConfigComponent()
            : base("GUI Config", "GUIConfig",
                   "Opens the variable-linking window. Connect Config to Transfer Variables MATLAB.") { }

        public override Guid ComponentGuid => new Guid("0b3f5c8e-7a41-4d6b-8d0a-1f2a3b4c5d02");
        protected override System.Drawing.Bitmap Icon => HabSimIcons.Config;
        public override GH_Exposure Exposure => GH_Exposure.secondary;

        protected override void RegisterInputParams(GH_InputParamManager p)
        {
            p.AddTextParameter("Names", "Names", "Variable names.", GH_ParamAccess.list);
            p.AddGenericParameter("Values", "Values", "Values, one branch per variable.", GH_ParamAccess.tree);
            p.AddTextParameter("MatlabFile", "MatlabFile", "MATLAB .m file the variables are linked to.", GH_ParamAccess.item);
            p.AddTextParameter("PythonExe", "PythonExe", "Optional full path to python.exe.", GH_ParamAccess.item);
            p.AddBooleanParameter("Open", "Open", "Button: open the configuration window.", GH_ParamAccess.item);
            for (int i = 0; i < p.ParamCount; i++) p[i].Optional = true;
        }

        protected override void RegisterOutputParams(GH_OutputParamManager p)
        {
            p.AddTextParameter("Config", "Config", "Path of the saved configuration.", GH_ParamAccess.item);
            p.AddTextParameter("Status", "Status", "Status message.", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            string configPath = Path.Combine(PyBridge.WorkDir, "transfer_config.json");
            string status;

            bool open = false;
            DA.GetData(4, ref open);
            bool edge = open && !_wasOpen; _wasOpen = open;

            if (edge)
            {
                var names = new List<string>();
                string matlabFile = null, python = null;
                DA.GetDataList(0, names);
                GH_Structure<IGH_Goo> tree;
                DA.GetDataTree(1, out tree);
                DA.GetData(2, ref matlabFile);
                DA.GetData(3, ref python);

                var w = new JsonWriter().BeginObject();
                w.Key("names"); GhJson.StringList(w, names);
                w.Key("values").Raw(GhJson.Tree(tree));
                w.Prop("matlab_file", matlabFile ?? "");
                if (!string.IsNullOrWhiteSpace(python)) w.Prop("python_exe", python);
                w.EndObject();

                var reply = PyBridge.Run("config-open", w.ToString(), python, 30000);
                status = reply.Get("status");
                if (reply.Flag("error")) Error(status);
            }
            else
            {
                status = File.Exists(configPath) ? "Saved config found." : "No config yet - press Open.";
                try
                {
                    string lastFile = Path.Combine(PyBridge.WorkDir, "last_gui_status.txt");
                    if (File.Exists(lastFile))
                    {
                        string last = File.ReadAllText(lastFile).Trim();
                        if (last.Length > 0) status += "  |  Last Open: " + last;
                    }
                }
                catch { }
            }

            DA.SetData(0, configPath);
            DA.SetData(1, status);
        }
    }
}
