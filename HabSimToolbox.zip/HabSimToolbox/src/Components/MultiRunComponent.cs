using System;
using System.Collections.Generic;
using System.Threading;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Parameters;
using Grasshopper.Kernel.Types;

namespace HabSim
{
    public class MultiRunComponent : HabSimComponent, IGH_VariableParameterComponent
    {
        // Fixed inputs. Optional Names_N / Values_N pairs are added by the user (zoom in, click +)
        // and always come after these.
        private const int IdxNames = 0, IdxValues = 1, IdxEntNames = 2, IdxEntValues = 3,
                          IdxOpen = 4, IdxStop = 5, IdxSavePath = 6, IdxPython = 7,
                          FixedCount = 8;

        private bool _wasOpen, _wasStop;
        private int _watchGeneration;

        public MultiRunComponent()
            : base("Multi-run", "MultiRun",
                   "Opens the multi-run editor and fires Trigger once per iteration. " +
                   "Connect Trigger to Transfer Variables MATLAB (TriggerIn).") { }

        public override Guid ComponentGuid => new Guid("0b3f5c8e-7a41-4d6b-8d0a-1f2a3b4c5d01");
        protected override System.Drawing.Bitmap Icon => HabSimIcons.Multirun;
        public override GH_Exposure Exposure => GH_Exposure.primary;

        protected override void RegisterInputParams(GH_InputParamManager p)
        {
            // Every input is optional: they are only validated when Open is pressed.
            Opt(p, p.AddTextParameter("Names", "Names", "Baseline variable names.", GH_ParamAccess.list));
            Opt(p, p.AddGenericParameter("Values", "Values", "Baseline values, one branch per variable.", GH_ParamAccess.tree));
            Opt(p, p.AddGenericParameter("EntwinedNames", "EntwinedNames", "Optional Entwine-based iteration names.", GH_ParamAccess.tree));
            Opt(p, p.AddGenericParameter("EntwinedValues", "EntwinedValues", "Optional Entwine-based iteration values.", GH_ParamAccess.tree));
            Opt(p, p.AddBooleanParameter("Open", "Open", "Button: open the multi-run editor.", GH_ParamAccess.item));
            Opt(p, p.AddBooleanParameter("Stop", "Stop", "Button: stop after the current iteration.", GH_ParamAccess.item));
            Opt(p, p.AddTextParameter("SavePath", "SavePath", "Optional JSON file/folder for this batch record.", GH_ParamAccess.item));
            Opt(p, p.AddTextParameter("PythonExe", "PythonExe", "Optional full path to python.exe.", GH_ParamAccess.item));
        }

        private static void Opt(GH_InputParamManager p, int index) { p[index].Optional = true; }

        protected override void RegisterOutputParams(GH_OutputParamManager p)
        {
            p.AddBooleanParameter("Trigger", "Trigger", "Pulses once per iteration.", GH_ParamAccess.item);
            p.AddIntegerParameter("Iteration", "Iteration", "Current iteration number.", GH_ParamAccess.item);
            p.AddTextParameter("Status", "Status", "Status message.", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            HabSimHost.Controller = this;

            bool open = false, stop = false;
            string savePath = null, python = null;
            DA.GetData(IdxOpen, ref open);
            DA.GetData(IdxStop, ref stop);
            DA.GetData(IdxSavePath, ref savePath);
            DA.GetData(IdxPython, ref python);

            bool openEdge = open && !_wasOpen; _wasOpen = open;
            bool stopEdge = stop && !_wasStop; _wasStop = stop;

            string status = "Idle. Press Open to configure a multi-run.";
            bool openFailed = false;

            if (openEdge)
            {
                var reply = PyBridge.Run("multirun-open", BuildOpenRequest(DA, savePath, python), python);
                status = reply.Get("status", status);
                if (reply.Flag("error")) { openFailed = true; Error(status); }
                else StartWatcher();
            }

            bool trigger = false;
            int iteration = 0;
            if (!openFailed && (stopEdge || HabSimHost.PeekStateStatus().Length > 0))
            {
                var req = new JsonWriter().BeginObject().Prop("stop", stopEdge).EndObject().ToString();
                var step = PyBridge.Run("multirun-step", req, python);
                trigger = step.Flag("trigger");
                iteration = step.Int("iteration");
                string s = step.Get("status");
                if (!string.IsNullOrEmpty(s)) status = s;
                if (step.Flag("error")) Error(status);
            }

            if (trigger) ScheduleNext();

            DA.SetData(0, trigger);
            DA.SetData(1, iteration);
            DA.SetData(2, status);
        }

        // ------------------------------------------------------------ helpers
        private string BuildOpenRequest(IGH_DataAccess DA, string savePath, string python)
        {
            var w = new JsonWriter().BeginObject();

            var names = new List<string>();
            DA.GetDataList(IdxNames, names);
            w.Key("names"); GhJson.StringList(w, names);
            w.Key("values").Raw(ReadTree(DA, IdxValues));

            bool entNamesOn = Params.Input[IdxEntNames].SourceCount > 0;
            bool entValuesOn = Params.Input[IdxEntValues].SourceCount > 0;
            if (entNamesOn) w.Key("ent_names").Raw(ReadTree(DA, IdxEntNames));
            if (entValuesOn) w.Key("ent_values").Raw(ReadTree(DA, IdxEntValues));

            w.Key("pairs").BeginArray();
            // Optional user-added pairs: Names_1, Values_1, Names_2, Values_2 ... after the fixed inputs.
            for (int nIdx = FixedCount, k = 1; nIdx + 1 < Params.Input.Count; nIdx += 2, k++)
            {
                int vIdx = nIdx + 1;
                bool nOn = Params.Input[nIdx].SourceCount > 0;
                bool vOn = Params.Input[vIdx].SourceCount > 0;
                if (!nOn && !vOn) continue;
                w.BeginObject().Prop("i", k);
                if (nOn)
                {
                    var list = new List<string>();
                    DA.GetDataList(nIdx, list);
                    w.Key("names"); GhJson.StringList(w, list);
                }
                if (vOn) w.Key("values").Raw(ReadTree(DA, vIdx));
                w.EndObject();
            }
            w.EndArray();

            if (!string.IsNullOrWhiteSpace(savePath)) w.Prop("save_path", savePath);
            if (!string.IsNullOrWhiteSpace(python)) w.Prop("python_exe", python);
            return w.EndObject().ToString();
        }

        private static string ReadTree(IGH_DataAccess DA, int index)
        {
            GH_Structure<IGH_Goo> tree;
            DA.GetDataTree(index, out tree);
            return GhJson.Tree(tree);
        }

        private void ScheduleNext()
        {
            try
            {
                var doc = OnPingDocument();
                if (doc != null)
                    doc.ScheduleSolution(10, d => ExpireSolution(false));
            }
            catch { }
        }

        /// <summary>Waits (cheaply, without Python) for the editor to queue a batch, then recomputes.</summary>
        private void StartWatcher()
        {
            int generation = Interlocked.Increment(ref _watchGeneration);
            var thread = new Thread(() =>
            {
                DateTime deadline = DateTime.UtcNow.AddHours(2);
                while (DateTime.UtcNow < deadline && generation == _watchGeneration)
                {
                    string st = HabSimHost.PeekStateStatus();
                    if (st == "queued") { HabSimHost.ExpireOnUi(this); return; }
                    if (st == "complete" || st == "error" || st == "cancelled") return;
                    Thread.Sleep(400);
                }
            });
            thread.IsBackground = true;
            thread.Name = "habsim-multirun-watch";
            thread.Start();
        }

        // ---------------------------------------------- variable parameters (Names_N / Values_N)
        bool IGH_VariableParameterComponent.CanInsertParameter(GH_ParameterSide side, int index) =>
            side == GH_ParameterSide.Input && index >= FixedCount;

        bool IGH_VariableParameterComponent.CanRemoveParameter(GH_ParameterSide side, int index) =>
            side == GH_ParameterSide.Input && index >= FixedCount;

        IGH_Param IGH_VariableParameterComponent.CreateParameter(GH_ParameterSide side, int index)
        {
            // Even offset = Names_k (list of text); odd offset = Values_k (tree).
            int offset = index - FixedCount;
            int k = offset / 2 + 1;
            if (offset % 2 == 0)
            {
                var names = new Param_String { Name = "Names_" + k, NickName = "Names_" + k,
                    Description = "Optional variable names for iteration " + k + ".",
                    Access = GH_ParamAccess.list, Optional = true };
                return names;
            }
            return new Param_GenericObject { Name = "Values_" + k, NickName = "Values_" + k,
                Description = "Values paired with Names_" + k + ".",
                Access = GH_ParamAccess.tree, Optional = true };
        }

        bool IGH_VariableParameterComponent.DestroyParameter(GH_ParameterSide side, int index) => true;

        void IGH_VariableParameterComponent.VariableParameterMaintenance()
        {
            for (int i = FixedCount; i < Params.Input.Count; i++)
            {
                int offset = i - FixedCount;
                int k = offset / 2 + 1;
                string name = (offset % 2 == 0 ? "Names_" : "Values_") + k;
                var param = Params.Input[i];
                param.Name = name;
                param.NickName = name;
                param.Optional = true;
                param.Access = offset % 2 == 0 ? GH_ParamAccess.list : GH_ParamAccess.tree;
            }
        }
    }
}
