using System;
using System.IO;
using Grasshopper.Kernel;

namespace HabSim
{
    public class RunMatlabComponent : HabSimComponent
    {
        private MatlabRun _run;
        private bool _wasTrigger;
        private readonly object _lock = new object();

        public RunMatlabComponent()
            : base("Run MATLAB", "RunMATLAB",
                   "Runs the MATLAB script on a rising edge of Trigger and reports completion. " +
                   "In a multi-run it reports back to the controller automatically.") { }

        public override Guid ComponentGuid => new Guid("0b3f5c8e-7a41-4d6b-8d0a-1f2a3b4c5d05");
        protected override System.Drawing.Bitmap Icon => HabSimIcons.RunMatlab;
        public override GH_Exposure Exposure => GH_Exposure.primary;

        protected override void RegisterInputParams(GH_InputParamManager p)
        {
            p.AddTextParameter("MatlabFile", "MatlabFile", "MATLAB .m file to execute.", GH_ParamAccess.item);
            p.AddTextParameter("MATLABRoot", "MATLABRoot", "MATLAB installation folder (what matlabroot returns), not the bin folder.", GH_ParamAccess.item);
            p.AddTextParameter("PythonExe", "PythonExe", "Optional full path to python.exe.", GH_ParamAccess.item);
            p.AddBooleanParameter("Trigger", "Trigger", "From Transfer Variables MATLAB or CSV.", GH_ParamAccess.item);
            for (int i = 0; i < p.ParamCount; i++) p[i].Optional = true;
        }

        protected override void RegisterOutputParams(GH_OutputParamManager p)
        {
            p.AddBooleanParameter("Ready", "Ready", "True once MATLAB completed successfully.", GH_ParamAccess.item);
            p.AddTextParameter("Status", "Status", "Status message.", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            string matlabFile = null, matlabRoot = null, python = null;
            bool trigger = false;
            DA.GetData(0, ref matlabFile);
            DA.GetData(1, ref matlabRoot);
            DA.GetData(2, ref python);
            DA.GetData(3, ref trigger);

            bool ready = false;
            string status = "Idle. Waiting for Trigger.";
            string note = "";
            bool risingEdge = trigger && !_wasTrigger;
            _wasTrigger = trigger;

            try
            {
                string stateStatus = "";
                int index = 0, total = 0;
                string stateError = "";
                if (HabSimHost.PeekStateStatus().Length > 0)
                {
                    var info = PyBridge.Run("multirun-info", "{}", python);
                    stateStatus = info.Get("status");
                    index = info.Int("index");
                    total = info.Int("total");
                    stateError = info.Get("error");
                }

                bool multiActive = stateStatus == "running";
                bool multiSession = multiActive ||
                    ((stateStatus == "error" || stateStatus == "complete") && !risingEdge);

                if (risingEdge)
                {
                    if (_run != null && _run.Running)
                        note = "Already running. Waiting for the current MATLAB run. ";
                    else
                    {
                        Validate(matlabFile, matlabRoot);
                        if (multiActive)
                        {
                            PyBridge.Run("multirun-marker",
                                new JsonWriter().BeginObject().Prop("matlab_file", Path.GetFullPath(matlabFile)).EndObject().ToString(),
                                python);
                            StartMultiRun(python, matlabFile, matlabRoot);
                        }
                        else
                        {
                            _run = new MatlabRun(python, matlabFile, matlabRoot, () => HabSimHost.ExpireOnUi(this));
                        }
                    }
                }

                if (multiSession)
                {
                    if (_run != null)
                    {
                        ready = _run.Done && _run.Status == 0;
                        if (_run.Done && _run.Status != 0)
                            status = "MATLAB failed with status " + _run.Status + " on this iteration.";
                        else if (_run.Done)
                            status = "MATLAB completed. Multi-run controller is advancing.";
                        else
                            status = "Running MATLAB for iteration " + (index + 1) + " of " + total +
                                     " (" + _run.Elapsed + " s)...";
                    }
                    else if (stateStatus == "complete") status = "Multi-run complete.";
                    else if (stateStatus == "error") status = string.IsNullOrEmpty(stateError) ? "Multi-run stopped after an error." : stateError;
                    else status = "Waiting for the multi-run controller to start MATLAB.";
                }
                else if (_run != null)
                {
                    ready = _run.Done && _run.Status == 0;
                    status = _run.Done
                        ? (_run.Status == 0 ? "MATLAB completed successfully." : "MATLAB failed with status " + _run.Status + ".")
                        : "Running MATLAB (" + _run.Elapsed + " s so far)...";
                }
            }
            catch (Exception ex)
            {
                ready = false;
                status = "ERROR: " + ex.Message;
                Error(status);
                // Do not leave a running batch hanging.
                if (HabSimHost.PeekStateStatus() == "running")
                {
                    PyBridge.Run("multirun-finish", "{\"code\":1}", python);
                    HabSimHost.WakeController(this);
                }
            }

            DA.SetData(0, ready);
            DA.SetData(1, note + status);
        }

        private static void Validate(string matlabFile, string matlabRoot)
        {
            if (string.IsNullOrWhiteSpace(matlabFile)) throw new ArgumentException("MatlabFile is empty. Connect the MATLAB script path.");
            if (!File.Exists(matlabFile)) throw new FileNotFoundException("MatlabFile does not exist: " + matlabFile);
            if (string.IsNullOrWhiteSpace(matlabRoot)) throw new ArgumentException("MATLABRoot is empty. Connect the MATLAB installation root.");
            if (!Directory.Exists(matlabRoot)) throw new DirectoryNotFoundException("MATLAB Root folder does not exist: " + matlabRoot);
        }

        /// <summary>Batch iteration: when MATLAB finishes, advance the batch and wake the controller once.</summary>
        private void StartMultiRun(string python, string matlabFile, string matlabRoot)
        {
            bool reported = false;
            MatlabRun run = null;

            Action handler = () =>
            {
                int code;
                lock (_lock)
                {
                    if (run == null || !run.Done || reported) return;
                    reported = true;
                    code = run.Status;
                }
                var reply = PyBridge.Run("multirun-finish",
                    new JsonWriter().BeginObject().Prop("code", code).EndObject().ToString(), python);
                // One controller wake-up is enough to recompute the downstream chain;
                // two independent expirations can race the next Run pulse.
                if (reply.Flag("advanced")) HabSimHost.WakeController(this);
            };

            run = new MatlabRun(python, matlabFile, matlabRoot, null);
            run.OnChange = handler;
            _run = run;
            if (run.Done) handler();   // finished before the callback was attached
        }
    }
}
