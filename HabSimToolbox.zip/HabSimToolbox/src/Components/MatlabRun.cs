using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace HabSim
{
    /// <summary>Launches python/run_matlab.py in its own console and watches it
    /// (C# port of gh_matlab_run.ScriptRun).</summary>
    public class MatlabRun
    {
        public const string MarkerName = "matlab_run_done.txt"; // same name as run_matlab_import_python_v2.py

        private readonly Process _proc;
        private readonly string _marker;
        private readonly DateTime _start = DateTime.UtcNow;
        private DateTime? _end;

        /// <summary>Called from the watcher thread when MATLAB has finished. May be set after construction.</summary>
        public volatile Action OnChange;

        public volatile bool Done;
        public volatile bool Running = true;
        public int Status;

        public int Elapsed => (int)((_end ?? DateTime.UtcNow) - _start).TotalSeconds;

        public MatlabRun(string pythonExe, string matlabFile, string matlabRoot, Action onChange)
        {
            string script = Path.Combine(PyBridge.PythonDir, "run_matlab.py");
            if (!File.Exists(script)) throw new FileNotFoundException("run_matlab.py is missing from the plugin's python folder.", script);

            matlabFile = Path.GetFullPath(matlabFile);
            matlabRoot = Path.GetFullPath(matlabRoot);
            _marker = Path.Combine(Path.GetDirectoryName(matlabFile) ?? ".", MarkerName);
            OnChange = onChange;

            try { if (File.Exists(_marker)) File.Delete(_marker); } catch { }

            Process started = null;
            Exception last = null;
            foreach (var cand in PyBridge.Candidates(pythonExe))
            {
                try
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = cand[0],
                        Arguments = (cand[1].Length > 0 ? cand[1] + " " : "") + "\"" + script + "\"",
                        WorkingDirectory = PyBridge.PythonDir,
                        UseShellExecute = false,
                        CreateNoWindow = false,   // run_matlab.py gets its own console window
                    };
                    PyBridge.CleanEnvironment(psi);
                    psi.EnvironmentVariables["HABSIM_AUTO_CLOSE"] = "1";
                    psi.EnvironmentVariables["HABSIM_MATLAB_FILE"] = matlabFile;
                    psi.EnvironmentVariables["HABSIM_MATLAB_ROOT"] = matlabRoot;
                    started = Process.Start(psi);
                    break;
                }
                catch (Win32Exception ex) { last = ex; }
            }
            if (started == null)
                throw new InvalidOperationException("Could not start Python" +
                    (last != null ? " (" + last.Message + ")" : "") + ". Set the PythonExe input.");
            _proc = started;

            var t = new Thread(Watch) { IsBackground = true, Name = "habsim-matlab-watch" };
            t.Start();
        }

        private int? ReadMarker()
        {
            try
            {
                string text = File.ReadAllText(_marker).Trim();
                return int.TryParse(text, out int v) ? v : (int?)null;
            }
            catch { return null; }
        }

        private void Watch()
        {
            // Wait for the launcher process itself, not just the marker: MATLAB writes the
            // marker just before exiting, and the next iteration must not start while the
            // previous MATLAB is still shutting down.
            while (!_proc.HasExited) Thread.Sleep(500);
            _proc.WaitForExit();

            int? marker = ReadMarker();
            int code = _proc.ExitCode;
            Status = marker ?? code;
            _end = DateTime.UtcNow;
            Running = false;
            Done = true;
            try { OnChange?.Invoke(); } catch { }
        }
    }
}
