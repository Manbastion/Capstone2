using System.Drawing;
using System.Reflection;

namespace HabSim
{
    /// <summary>Loads the 24x24 block icons embedded in the .gha (icons\*_24.png).</summary>
    public static class HabSimIcons
    {
        public static Bitmap Multirun => Load("multirun");
        public static Bitmap Matlab => Load("matlab");
        public static Bitmap RunMatlab => Load("run_matlab");
        public static Bitmap Csv => Load("csv");
        public static Bitmap Config => Load("config");
        public static Bitmap History => Load("history");
        public static Bitmap Notification => Load("notification");

        private static Bitmap Load(string name)
        {
            try
            {
                var stream = Assembly.GetExecutingAssembly()
                    .GetManifestResourceStream("HabSim.icons." + name + "_24.png");
                if (stream == null) return null;
                using (stream)
                using (var loaded = new Bitmap(stream))
                    return new Bitmap(loaded);   // copy: a Bitmap needs its stream open for life, so detach it
            }
            catch { return null; }   // a missing icon must never stop the plugin loading
        }
    }
}
