using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using Rhino.Geometry;

namespace HabSim
{
    /// <summary>Tiny JSON writer (no external dependency, so no version clashes inside Rhino).</summary>
    public class JsonWriter
    {
        private readonly StringBuilder _sb = new StringBuilder();
        private readonly Stack<bool> _needComma = new Stack<bool>();
        private bool _afterKey;

        /// <summary>Comma handling before any value or key.</summary>
        private void Before()
        {
            if (_afterKey) { _afterKey = false; return; }
            if (_needComma.Count > 0)
            {
                if (_needComma.Peek()) _sb.Append(',');
                _needComma.Pop();
                _needComma.Push(true);
            }
        }

        public JsonWriter BeginObject() { Before(); _sb.Append('{'); _needComma.Push(false); return this; }
        public JsonWriter EndObject() { _sb.Append('}'); _needComma.Pop(); return this; }
        public JsonWriter BeginArray() { Before(); _sb.Append('['); _needComma.Push(false); return this; }
        public JsonWriter EndArray() { _sb.Append(']'); _needComma.Pop(); return this; }

        public JsonWriter Key(string key)
        {
            Before();
            WriteString(key);
            _sb.Append(':');
            _afterKey = true;
            return this;
        }

        public JsonWriter Null() { Before(); _sb.Append("null"); return this; }
        public JsonWriter Bool(bool v) { Before(); _sb.Append(v ? "true" : "false"); return this; }
        public JsonWriter Str(string v)
        {
            if (v == null) return Null();
            Before(); WriteString(v); return this;
        }
        public JsonWriter Num(double v)
        {
            if (double.IsNaN(v) || double.IsInfinity(v)) return Null();
            Before(); _sb.Append(v.ToString("R", CultureInfo.InvariantCulture)); return this;
        }

        public JsonWriter Prop(string key, string v) { Key(key); return Str(v); }
        public JsonWriter Prop(string key, bool v) { Key(key); return Bool(v); }
        public JsonWriter Prop(string key, double v) { Key(key); return Num(v); }

        /// <summary>Embed an already-built JSON fragment as a value.</summary>
        public JsonWriter Raw(string json) { Before(); _sb.Append(json); return this; }

        private void WriteString(string s)
        {
            _sb.Append('"');
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"': _sb.Append("\\\""); break;
                    case '\\': _sb.Append("\\\\"); break;
                    case '\n': _sb.Append("\\n"); break;
                    case '\r': _sb.Append("\\r"); break;
                    case '\t': _sb.Append("\\t"); break;
                    default:
                        if (c < 0x20) _sb.Append("\\u").Append(((int)c).ToString("x4"));
                        else _sb.Append(c);
                        break;
                }
            }
            _sb.Append('"');
        }

        public override string ToString() => _sb.ToString();
    }

    /// <summary>Converts Grasshopper data into the JSON shapes bridge_cli.py expects.</summary>
    public static class GhJson
    {
        public static void WriteItem(JsonWriter w, object value)
        {
            if (value is IGH_Goo goo) value = goo.ScriptVariable();

            switch (value)
            {
                case null: w.Null(); break;
                case bool b: w.Bool(b); break;
                case int i: w.Num(i); break;
                case long l: w.Num(l); break;
                case float f: w.Num(f); break;
                case double d: w.Num(d); break;
                case string s: w.Str(s); break;
                case Point3d p: WriteXyz(w, p.X, p.Y, p.Z); break;
                case Vector3d v: WriteXyz(w, v.X, v.Y, v.Z); break;
                case Point3f pf: WriteXyz(w, pf.X, pf.Y, pf.Z); break;
                case Point2d p2: w.BeginArray().Num(p2.X).Num(p2.Y).EndArray(); break;
                case IEnumerable seq:
                    w.BeginArray();
                    foreach (var item in seq) WriteItem(w, item);
                    w.EndArray();
                    break;
                default: w.Str(value.ToString()); break;
            }
        }

        private static void WriteXyz(JsonWriter w, double x, double y, double z) =>
            w.BeginArray().Num(x).Num(y).Num(z).EndArray();

        /// <summary>{"paths":[[0],[1]],"branches":[[...],[...]]}</summary>
        public static string Tree(GH_Structure<IGH_Goo> tree)
        {
            var w = new JsonWriter();
            w.BeginObject();
            w.Key("paths").BeginArray();
            if (tree != null)
                foreach (GH_Path path in tree.Paths)
                {
                    w.BeginArray();
                    foreach (int idx in path.Indices) w.Num(idx);
                    w.EndArray();
                }
            w.EndArray();
            w.Key("branches").BeginArray();
            if (tree != null)
                for (int b = 0; b < tree.Branches.Count; b++)
                {
                    w.BeginArray();
                    foreach (IGH_Goo item in tree.Branches[b]) WriteItem(w, item);
                    w.EndArray();
                }
            w.EndArray();
            w.EndObject();
            return w.ToString();
        }

        public static void StringList(JsonWriter w, IEnumerable<string> items)
        {
            w.BeginArray();
            if (items != null) foreach (var s in items) w.Str(s);
            w.EndArray();
        }
    }
}
