using System;
using System.Drawing;
using Grasshopper.Kernel;

namespace HabSim
{
    public class HabSimInfo : GH_AssemblyInfo
    {
        public override string Name => "HabSim Toolbox";
        public override Bitmap Icon => HabSimIcons.Multirun;
        public override string Description =>
            "Transfer Grasshopper variables into MATLAB / CSV files, run MATLAB, and repeat for multiple iterations.";
        public override Guid Id => new Guid("6b1d7e3a-52c4-4f0e-9a52-0c1f8f6d3a01");
        public override string AuthorName => "HabSim";
        public override string AuthorContact => "";
    }

    /// <summary>Puts the HabSim tab on the ribbon.</summary>
    public class HabSimCategoryIcon : GH_AssemblyPriority
    {
        public override GH_LoadingInstruction PriorityLoad()
        {
            Grasshopper.Instances.ComponentServer.AddCategorySymbolName("HabSim", 'H');
            var tabIcon = HabSimIcons.Multirun;
            if (tabIcon != null)
                Grasshopper.Instances.ComponentServer.AddCategoryIcon("HabSim", tabIcon);
            return GH_LoadingInstruction.Proceed;
        }
    }
}
