# HabSim Toolbox: Setup Guide

HabSim Toolbox is a Grasshopper plugin (`HabSimToolbox.gha`). It writes Grasshopper values into a MATLAB `.m` file and/or a CSV file, runs MATLAB, and can repeat that for many iterations.

The five blocks are in the **HabSim** tab of Grasshopper, in the **MATLAB** panel. They are ordinary Grasshopper components. There is nothing to paste into Python script components and no project folder to connect.

**Contents**
1. [Requirements](#1-requirements)
2. [Build the plugin (once)](#2-build-the-plugin-once)
3. [Install it](#3-install-it)
4. [Check Python and MATLAB](#4-check-python-and-matlab)
5. [Your first run](#5-your-first-run)
6. [The blocks](#6-the-blocks)
7. [Wiring patterns](#7-wiring-patterns)
8. [Multi-run](#8-multi-run)
9. [Notifications](#9-notifications)
10. [Where things are stored](#10-where-things-are-stored)
11. [Updating or uninstalling](#11-updating-or-uninstalling)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. Requirements

- Windows 10 or 11
- Rhino 8 with Grasshopper (Rhino 7 may work with the `net48` build, but it is untested)
- MATLAB R2021a or newer
- Python 3.10 or newer **with tkinter**. The editor windows and notification pop-ups are Python/tkinter windows. The standard python.org installer includes tkinter.
- To build the plugin: the .NET SDK (version 8 or newer) from https://dotnet.microsoft.com/download, and an internet connection for the first build (NuGet downloads the Grasshopper reference files).

## 2. Build the plugin (once)

1. Unzip `HabSimToolbox.zip` somewhere permanent, for example `C:\Dev\HabSimToolbox`.
2. Double-click **`build.bat`**. This is the same as running `dotnet build -c Release`.
3. When it finishes, check that this folder exists and contains `HabSimToolbox.gha` and a `python` folder:

   ```text
   dist\net48\
   ```

`build.bat` also builds `dist\net7.0-windows\`. Use that one only if you have switched Rhino 8 to the .NET Core runtime. If you are unsure, use `net48`; it is Rhino 8's default.

The build copies all Python files and the icons into `dist\`. You do not need to build again unless you change the C# code in `src\`.

## 3. Install it

1. **Close Rhino.**
2. Delete any old `%APPDATA%\Grasshopper\Libraries\HabSimToolbox` folder. Grasshopper loads every `.gha` it finds, so a leftover copy causes errors.
3. Create a new folder `%APPDATA%\Grasshopper\Libraries\HabSimToolbox` and copy the **contents of `dist\net48\`** into it. The `.gha` and the `python` folder must sit side by side:

   ```text
   %APPDATA%\Grasshopper\Libraries\HabSimToolbox\
       HabSimToolbox.gha
       python\
   ```

   Do not copy the whole project folder. Copying it puts a second `.gha` in `obj\`, which has no `python` folder beside it.
4. Right-click `HabSimToolbox.gha` > **Properties** > tick **Unblock** > **OK**. If there is no Unblock box, skip this step.
5. Start Rhino, then open Grasshopper. A **HabSim** tab with a **MATLAB** panel should appear, and its blocks have icons.

The tab does not appear? See [Troubleshooting](#12-troubleshooting).

## 4. Check Python and MATLAB

**Python.** In a Command Prompt, run:

```bat
python --version
python -c "import tkinter"
```

Both should succeed (the second prints nothing). If either fails, you have two options:

- Put the full path to `python.exe` in the **PythonExe** input of each block, or
- Set a Windows environment variable `HABSIM_PYTHON` to that path, and restart Rhino.

If you leave **PythonExe** empty, the plugin tries `HABSIM_PYTHON`, then `python`, then `py -3`, then `python3`.

**MATLAB.** In MATLAB, run `matlabroot` and note the folder it returns, for example `C:\Program Files\MATLAB\R2024a`. You will paste it into Run MATLAB's **MATLABRoot** input. Use this folder, not its `bin` subfolder.

To check that MATLAB can run from the command line:

```bat
matlab -batch "disp('hello')"
```

## 5. Your first run

**Back up your `.m` and CSV files first.** Transfers edit them in place.

Try a single run on a copy of your example `.m` file before anything bigger.

1. Add a **Panel** with the full path to your `.m` file (a copy).
2. Add **Transfer Variables MATLAB**. Connect:
   - **Names**: your variable names (a list of text)
   - **Values**: the values, one branch per variable, in the same order as Names
   - **MatlabFile**: the `.m` path
   - **TriggerIn**: a **Button**
3. Add **Run MATLAB**. Connect:
   - **MatlabFile**: the same `.m` path
   - **MATLABRoot**: the `matlabroot` folder from step 4
   - **Trigger**: Transfer Variables MATLAB's **Trigger** output
4. Connect each block's **Status** output to a Panel. This is where errors show up.
5. Press the Button. A console window opens while MATLAB runs. When MATLAB finishes, Run MATLAB's **Ready** output becomes true and a notification appears (see [Notifications](#9-notifications)).

You do not need to set access types or type hints on inputs. Names is already a list and Values is already a tree. Each block's Status output explains most problems in plain words.

## 6. The blocks

Every input is optional in the sense that the block will not crash when empty. A block reports what it is missing in its **Status** output.

### Transfer Variables MATLAB

Writes Grasshopper values into a MATLAB `.m` file when **TriggerIn** is true. The `.m` file is changed in place.

| Input | Purpose |
|---|---|
| Names | Variable names (list) |
| Values | Values, one branch per variable (tree) |
| MatlabFile | The `.m` file to update |
| Config | Optional. The **Config** output of GUI Config |
| TriggerIn | A Button, or Multi-run's **Trigger** |
| PythonExe | Optional path to `python.exe` |

Outputs: **Trigger** (true after a successful transfer; connect it onward), **Report** (what changed), **Status**.

Without a saved GUI configuration, variables are matched by name. With one, the saved mapping is used.

### GUI Config

Opens a window where you link Grasshopper variables to MATLAB variables.

| Input | Purpose |
|---|---|
| Names, Values | The same as for Transfer Variables MATLAB |
| MatlabFile | The `.m` file the variables link to |
| PythonExe | Optional |
| Open | A Button that opens the window |

Outputs: **Config** (path of the saved configuration) and **Status**.

Use it like this:

1. Connect Names, Values and MatlabFile, then press **Open**.
2. Link your variables, then click **OK** in the window.
3. Connect **Config** to Transfer Variables MATLAB's **Config** input, and recompute.

The window also has **History** (past transfers, with revert), **Value Formats** and **Notifications…** buttons.

### Transfer Variables CSV

Updates mapped cells in a CSV file when **TriggerIn** is true. The CSV is changed in place.

| Input | Purpose |
|---|---|
| Names, Values | Variable names and values |
| CSVFile | The CSV to update |
| Mapping | One rule per item |
| TriggerIn | Transfer Variables MATLAB's **Trigger** |
| PythonExe | Optional |

Each mapping rule has four fields:

```text
variable | identifier column | identifier | column to change
```

For example:

```text
fan_repair_rate | Failure Mode (ID) | 5002001 | Repair Rate
radiator_t2f | Index | 1 | T2F
```

Without a trigger it only previews: it checks the mapping and shows what would change. With a trigger it writes the cells and sends **Trigger** onward.

### Run MATLAB

Runs your MATLAB script when **Trigger** goes from false to true.

| Input | Purpose |
|---|---|
| MatlabFile | The `.m` file to run |
| MATLABRoot | The folder `matlabroot` returns (not `bin`) |
| PythonExe | Optional |
| Trigger | From Transfer Variables MATLAB or CSV |

Outputs: **Ready** (true once MATLAB finished successfully) and **Status**.

MATLAB runs headless (no desktop), so figures are not shown. Your script has to save any outputs you want. The plugin finds the launcher (`run_matlab.py`) in its own `python` folder, so there is no path to set. In a multi-run, Run MATLAB reports back to Multi-run automatically.

### Multi-run

Opens an editor where you enter values for each iteration, then sends **Trigger** once per iteration. See [Multi-run](#8-multi-run).

## 7. Wiring patterns

**Single run**

```text
Button -> Transfer Variables MATLAB (TriggerIn)
          Transfer Variables MATLAB (Trigger) -> Run MATLAB (Trigger)
```

**Single run that also updates a CSV**

```text
Button -> Transfer Variables MATLAB (TriggerIn)
          Transfer Variables MATLAB (Trigger) -> Transfer Variables CSV (TriggerIn)
          Transfer Variables CSV (Trigger)    -> Run MATLAB (Trigger)
```

**Multi-run**

```text
Multi-run (Trigger) -> Transfer Variables MATLAB (TriggerIn)
                       Transfer Variables MATLAB (Trigger) -> [Transfer Variables CSV] -> Run MATLAB (Trigger)
```

Feed the same baseline **Names** and **Values** to Multi-run, Transfer Variables MATLAB and (if used) Transfer Variables CSV. Multi-run's **Trigger** goes to Transfer Variables MATLAB's **TriggerIn**, never straight to Run MATLAB.

## 8. Multi-run

**Inputs**

| Input | Purpose |
|---|---|
| Names, Values | Baseline variables |
| EntwinedNames, EntwinedValues | Optional. Iteration names/values built with Entwine |
| Open | A Button that opens the editor |
| Stop | A Button. Stops after the current iteration finishes |
| SavePath | Optional JSON file or folder for this batch record |
| PythonExe | Optional |

Outputs: **Trigger**, **Iteration** (the current iteration number) and **Status**.

**Running a batch**

1. Connect Names and Values, then press **Open**.
2. Enter the values for each iteration in the editor.
3. Click **Run iterations**. Multi-run sends one Trigger per iteration, waits for MATLAB to finish, then moves to the next. It stops if a transfer or a MATLAB run fails.

**Extra iteration inputs (optional).** Zoom in on the Multi-run block and click **+** at the bottom of its inputs. This adds `Names_1` / `Values_1`, then `Names_2` / `Values_2`, and so on. Rules:

- Always connect both inputs of a pair.
- Every name you supply must exist in the baseline Names list.
- Do not give the same variable for the same iteration through both a numbered pair and the Entwine inputs.

**Records.** At the end of each batch, a record is added to `history.json` (in the `python` folder). If you connect **SavePath**, a standalone JSON file is also saved there. If not, and MATLAB has a folder variable (such as `Output_Folder`) that your script changed during the run, `multirun_history.json` is saved in that folder.

## 9. Notifications

Notifications tell you when a run or a whole batch has finished.

- **Set up:** open GUI Config's window and click **Notifications…**, or double-click `python\Launch_Notifications.bat`. Tick **Enable notifications** and **Show a desktop alert**, press **Test desktop**, and then **Save settings**.
- **When to notify:**
  - *After each MATLAB run* gives one alert per run.
  - *Only at the end of the whole multi-run batch* gives one alert when the batch finishes. A single run, which has no batch, still alerts when it finishes.
  - Failures also alert if **Also alert me when processing fails** is ticked. Pressing **Stop** is silent.
- **Phone alerts (optional):** tick the phone option, press **Generate topic**, then subscribe to the same server and topic in the free ntfy app on your phone. Messages contain only status, elapsed time and result count.
- **Pop-up look:** a small window with the bell icon, shown for about 15 seconds, then it closes.

You do not need to run `00_Enable_Notifications.bat` any more. The notification hook is already built in.

To check without opening Rhino:

```bat
python python\habsim_notifications.py --check
python python\habsim_notifications.py --test
```

Delivery attempts are logged in `%USERPROFILE%\HabSim\notifications.log`.

## 10. Where things are stored

| What | Where |
|---|---|
| The plugin and its Python helpers | `%APPDATA%\Grasshopper\Libraries\HabSimToolbox\` (`.gha` and `python\` side by side) |
| Settings, saved GUI configuration, multi-run state, notification log | `%USERPROFILE%\HabSim\` |
| Run history (`history.json`) | the `python` folder |

There is no repository or project folder to set in Grasshopper. The plugin finds the `python` folder beside the `.gha` automatically (it also looks a few folders up).

## 11. Updating or uninstalling

- **Python or icon changes** (files in `python\`): copy the updated files into the installed `python` folder. They take effect the next time a block calls Python. You do not need to restart Rhino.
- **C# changes or a new build**: close Rhino, delete the old installed folder, install the new `dist\net48\` contents as in [step 3](#3-install-it), then restart Rhino.
- **Uninstall**: close Rhino and delete `%APPDATA%\Grasshopper\Libraries\HabSimToolbox\`. Optionally delete `%USERPROFILE%\HabSim\` to remove saved settings.

## 12. Troubleshooting

| Problem | What to do |
|---|---|
| No HabSim tab | Make sure the `.gha` is in `%APPDATA%\Grasshopper\Libraries\HabSimToolbox\`, unblock it, and restart Rhino. If you changed Rhino 8's runtime, install from `dist\net7.0-windows\` instead. Type `GrasshopperDeveloperSettings` in Rhino and check for load errors. |
| Build error about `Bitmap` / `System.Drawing` | Use the latest zip. Its `.csproj` references `System.Drawing.Common` for the `net7.0-windows` build. The `net48` build is enough for most people. |
| "The Python backend was not found at …" | The `python` folder is not beside the `.gha` that loaded. Delete duplicate copies (especially under `obj\`) and install from `dist\`. |
| "Could not start Python" | Fill in **PythonExe** or set `HABSIM_PYTHON` (see step 4). |
| Windows or editors do not open | Tkinter is missing. Reinstall Python from python.org with tcl/tk selected. |
| "MATLAB executable was not found" | **MATLABRoot** must be the `matlabroot` folder, not `bin`. |
| "MatlabFile must point to an existing MATLAB script" | Check the path in the Panel (no quotes or trailing spaces). |
| Transfer fails while MATLAB is running | Wait for MATLAB to finish before updating the same `.m` file. |
| CSV mapping fails | Check all four fields per line, and that the identifier and target columns exist in the CSV. |
| Names and Values do not match | Provide one Values branch per name, in the same order. |
| Multi-run stops | Read its **Status**. Bad iteration input, transfer failures and MATLAB errors stop the batch. |
| No notification | Run `python python\habsim_notifications.py --check`, then `--test`. Open **Notifications…**, check **Enable notifications** and **Show a desktop alert**, and read `%USERPROFILE%\HabSim\notifications.log`. |
| A block shows an error | Connect a Panel to **Status**, read the message, and send it with the build or runtime error text if you need help. |

Always back up your `.m` and CSV files before the first run. Transfers overwrite values in them.
