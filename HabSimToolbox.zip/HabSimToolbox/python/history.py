import json
import os
import uuid
import tkinter as tk
from pathlib import Path
from datetime import datetime
from tkinter import ttk, messagebox, filedialog

from habsim_icons import apply_icon
from variable_transfer_v2 import read_variables, set_variable_values
from value_files import export_transfer_values, record_value_rows

FILE = Path(__file__).with_name("history.json")
LIMIT = 500


def load_history():
    try:
        with open(FILE, encoding="utf-8") as file:
            data = json.load(file)

        # Backwards compatibility: ignore the obsolete one-time revert status.
        return [{k: v for k, v in row.items() if k != "reverted_at"}
                for row in data] if isinstance(data, list) else []

    except (OSError, json.JSONDecodeError):
        return []


def save_history(records):
    temp = FILE.with_suffix(".tmp")

    with open(temp, "w", encoding="utf-8") as file:
        json.dump([{k: v for k, v in r.items() if k != "reverted_at"}
                   for r in records[:LIMIT]], file, indent=2)

    os.replace(temp, FILE)


def record_transfer(
    source_file,
    destination_file,
    mode,
    selected_variables,
    transferred_variables,
    changes,
    mappings=None,
):
    record = {
        "id": uuid.uuid4().hex,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "source_file": os.path.abspath(source_file),
        "destination_file": os.path.abspath(destination_file),
        "source_name": os.path.basename(source_file),
        "destination_name": os.path.basename(destination_file),
        "mode": mode,
        "selected_variables": list(selected_variables or []),
        "transferred_variables": list(transferred_variables or []),
        "mappings": dict(mappings or {}),
        "changes": dict(changes or {}),
    }

    records = load_history()
    records.insert(0, record)
    save_history(records)

    return record


def delete_history_record(record_id):
    save_history(
        [
            record
            for record in load_history()
            if record.get("id") != record_id
        ]
    )


def conflicts(record):
    destination = record["destination_file"]

    if not os.path.isfile(destination):
        return ["The destination file no longer exists."]

    current = read_variables(destination)
    warnings = []

    for name, values in record.get("changes", {}).items():
        expected = str(values["after"])

        if current.get(name) not in (expected, str(values["before"])):
            warnings.append(
                f"{name}: destination is {current.get(name)!r}, "
                f"expected {expected!r}"
            )

    return warnings


def revert_transfer(record_id):
    records = load_history()
    record = next(
        (item for item in records if item.get("id") == record_id),
        None,
    )

    if not record:
        raise ValueError("History record not found.")

    if not record.get("changes"):
        raise ValueError("Nothing changed in this transfer.")

    destination = record["destination_file"]

    if not os.path.isfile(destination):
        raise FileNotFoundError(
            "Destination file no longer exists."
        )

    before = {
        name: values["before"]
        for name, values in record["changes"].items()
    }

    set_variable_values(destination, before, True)

    return record


def export_record_dialog(parent, record):
    timestamp = str(record.get("timestamp", "transfer")).replace(":", "-")
    destination = Path(record.get("destination_name", "values")).stem
    default_name = f"{destination}_{timestamp}_values"

    path = filedialog.asksaveasfilename(
        parent=parent,
        title="Export transfer values",
        initialfile=default_name,
        filetypes=[
            ("JSON file", "*.json"),
            ("Text file", "*.txt"),
            ("CSV file", "*.csv"),
        ],
    )
    if not path:
        return None

    if not Path(path).suffix:
        path += ".json"

    try:
        export_transfer_values(record, path)
    except (OSError, ValueError, RuntimeError, UnicodeError) as error:
        messagebox.showerror("Export failed", str(error), parent=parent)
        return None

    messagebox.showinfo(
        "Values exported",
        f"Transfer values saved to:\n{path}",
        parent=parent,
    )
    return path


class Details(tk.Toplevel):
    def __init__(self, parent, record):
        super().__init__(parent)

        self.title("Transfer Details")
        self.minsize(700, 480)

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        if record.get("record_type") == "multirun":
            text = (
                "Multi-run batch\n"
                f"Status: {record.get('status', 'unknown')}\n"
                f"Iterations: {record.get('total_iterations', 0)}\n"
                f"Time: {record.get('timestamp', '')}\n"
                f"Finished: {record.get('finished_at', '')}\n"
                f"Error: {record.get('error', '')}"
            )
        else:
            text = (
                f"Source: {record['source_file']}\n"
                f"Destination: {record['destination_file']}\n"
                f"Mode: {record['mode']}\n"
                f"Time: {record['timestamp']}"
            )

        ttk.Label(
            self,
            text=text,
            justify="left",
            wraplength=650,
        ).grid(
            row=0,
            column=0,
            sticky="ew",
            padx=12,
            pady=12,
        )

        tree = ttk.Treeview(
            self,
            columns=("source", "destination", "before", "after"),
            show="headings",
        )

        for column, title in (
            ("source", "Source"),
            ("destination", "Destination"),
            ("before", "Before"),
            ("after", "After"),
        ):
            tree.heading(column, text=title)

        tree.grid(
            row=1,
            column=0,
            sticky="nsew",
            padx=12,
        )

        if record.get("record_type") == "multirun":
            for iteration in record.get("iterations", []):
                for name, value in iteration.get("changed_variables", {}).items():
                    tree.insert("", "end", values=(
                        "Iteration %s" % iteration.get("iteration", ""),
                        name, "", value
                    ))
        else:
            for values in record_value_rows(record):
                tree.insert(
                    "",
                    "end",
                    values=(
                        values.get("source", ""),
                        values.get("destination", ""),
                        "" if values.get("before") is None else values.get("before"),
                        "" if values.get("after") is None else values.get("after"),
                    ),
                )

        buttons = ttk.Frame(self)
        buttons.grid(row=2, column=0, sticky="ew", padx=12, pady=12)
        ttk.Button(
            buttons,
            text="Export Values…",
            command=lambda: export_record_dialog(self, record),
        ).pack(side="left")
        ttk.Button(
            buttons,
            text="Close",
            command=self.destroy,
        ).pack(side="right")


class HistoryWindow(tk.Toplevel):
    def __init__(self, parent, on_revert=None):
        super().__init__(parent)

        self.title("Transfer History")
        apply_icon(self, "history")
        self.minsize(980, 500)

        self.on_revert = on_revert
        self.map = {}

        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self.tree = ttk.Treeview(
            self,
            columns=(
                "time",
                "source",
                "dest",
                "mode",
                "mapped",
                "changed",
            ),
            show="headings",
            selectmode="browse",
        )

        for column, title in (
            ("time", "Time"),
            ("source", "Source"),
            ("dest", "Destination"),
            ("mode", "Mode"),
            ("mapped", "Mapped"),
            ("changed", "Changed"),
        ):
            self.tree.heading(column, text=title)

        self.tree.grid(
            row=0,
            column=0,
            sticky="nsew",
            padx=12,
            pady=(12, 6),
        )

        self.tree.bind("<Double-1>", lambda _: self.view())

        buttons = ttk.Frame(self)
        buttons.grid(
            row=1,
            column=0,
            sticky="ew",
            padx=12,
            pady=(0, 12),
        )

        for text, command in (
            ("View Details", self.view),
            ("Export Values…", self.export),
            ("Revert Variables", self.revert),
            ("Delete Record", self.delete),
            ("Refresh", self.refresh),
        ):
            ttk.Button(
                buttons,
                text=text,
                command=command,
            ).pack(side="left", padx=(0, 6))

        ttk.Button(
            buttons,
            text="Close",
            command=self.destroy,
        ).pack(side="right")

        self.refresh()

    def selected(self):
        selection = self.tree.selection()
        return self.map.get(selection[0]) if selection else None

    def refresh(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        self.map.clear()

        for record in load_history():
            if record.get("record_type") == "multirun":
                values = (
                    record.get("timestamp", "").replace("T", " "),
                    "Multi-run batch",
                    record.get("status", ""),
                    "Multi-run",
                    record.get("total_iterations", 0),
                    sum(len(row.get("changed_variables", {}))
                        for row in record.get("iterations", [])),
                )
            else:
                values = (
                    record.get("timestamp", "").replace("T", " "),
                    record.get("source_name", ""),
                    record.get("destination_name", ""),
                    record.get("mode", ""),
                    len(record.get("mappings", {})),
                    len(record.get("changes", {})),
                )
            item = self.tree.insert("", "end", values=values)

            self.map[item] = record

    def view(self):
        record = self.selected()

        if record:
            Details(self, record)
        else:
            messagebox.showinfo(
                "History",
                "Select a transfer first.",
                parent=self,
            )

    def export(self):
        record = self.selected()
        if record and record.get("record_type") == "multirun":
            path = filedialog.asksaveasfilename(
                parent=self, title="Export multi-run record",
                defaultextension=".json", filetypes=[("JSON file", "*.json")]
            )
            if path:
                try:
                    with open(path, "w", encoding="utf-8") as stream:
                        json.dump(record, stream, indent=2, ensure_ascii=False)
                    messagebox.showinfo("Exported", "Multi-run record saved to:\n" + path, parent=self)
                except OSError as error:
                    messagebox.showerror("Export failed", str(error), parent=self)
            return
        if not record:
            messagebox.showinfo(
                "History",
                "Select a transfer first.",
                parent=self,
            )
            return
        export_record_dialog(self, record)

    def revert(self):
        record = self.selected()

        if not record:
            messagebox.showinfo(
                "History",
                "Select a transfer first.",
                parent=self,
            )
            return

        if record.get("record_type") == "multirun":
            messagebox.showinfo("History", "Multi-run records cannot be reverted.", parent=self)
            return

        warning = conflicts(record)

        message = (
            "Restore the recorded BEFORE values in the destination file?"
        )

        if warning:
            message += (
                "\n\nCurrent destination differs from the recorded "
                "post-transfer values:\n"
                + "\n".join(warning[:8])
            )

        if not messagebox.askyesno(
            "Revert transfer",
            message,
            parent=self,
        ):
            return

        try:
            revert_transfer(record["id"])

        except (OSError, ValueError, UnicodeError) as error:
            messagebox.showerror(
                "Revert failed",
                str(error),
                parent=self,
            )
            return

        self.refresh()

        if self.on_revert:
            self.on_revert()

        messagebox.showinfo(
            "Revert complete",
            "Previous destination values restored.",
            parent=self,
        )

    def delete(self):
        record = self.selected()

        if not record:
            return

        if messagebox.askyesno(
            "Delete record",
            "Delete this history record?",
            parent=self,
        ):
            delete_history_record(record["id"])
            self.refresh()
