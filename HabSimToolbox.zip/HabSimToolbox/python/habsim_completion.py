"""Small completion hook for the existing MATLAB/Grasshopper workflow.

No GUI imports, app build, MATLAB Engine or extra runtime packages.
"""
from functools import wraps
import time

from habsim_notifications import notify_completion


def _batch_active():
    """True while a multi-run batch is driving MATLAB."""
    try:
        import multirun
        state = multirun.load_state()
        return bool(state) and state.get("status") == "running"
    except Exception:
        return False


def _run_scope():
    """Scope to use for a single MATLAB run.

    With 'whole loop' selected, a MATLAB run that is NOT part of a multi-run batch
    would otherwise never alert (nothing signals the end of a loop), so it alerts
    as a run of its own.
    """
    try:
        from habsim_notifications import load_settings
        if load_settings().get("scope") == "loop" and not _batch_active():
            return "loop"
    except Exception:
        pass
    return "run"


def completed(success, elapsed=None, scope="run", wait=False, text_scope=None):
    """Alert delivery must never change the calculation's outcome."""
    try:
        receipt = notify_completion(success=success, elapsed_seconds=elapsed, scope=scope,
                                    text_scope=text_scope)
        if wait:
            # The CLI can exit immediately afterwards; delivery uses daemon threads.
            receipt.wait(45)
        return receipt
    except Exception:
        return None


def notify_run(function):
    """Wrap a runner returning a MATLAB status code; alert once per call."""
    @wraps(function)
    def run(*args, **kwargs):
        started = time.monotonic()
        success = False
        cancelled = False
        try:
            result = function(*args, **kwargs)
            success = result == 0
            return result
        except (KeyboardInterrupt, SystemExit):
            cancelled = True
            raise
        finally:
            if not cancelled:
                completed(success, time.monotonic() - started, scope=_run_scope(), text_scope="run", wait=True)
    return run


def notify_batch(state):
    """Called only on a batch terminal transition; deliberate Stop is silent.

    Whole-loop scope must be selected in settings. Per-run scope is handled
    by notify_run instead, so the two modes never produce duplicate alerts.
    """
    if state.get("status") in ("complete", "error"):
        started = state.get("started")
        elapsed = max(0, time.time() - started) if isinstance(started, (int, float)) else None
        # wait=True: this runs in a short-lived helper process that would otherwise exit
        # before the background delivery thread had started the pop-up.
        return completed(state["status"] == "complete", elapsed, scope="loop", wait=True)
    return None
