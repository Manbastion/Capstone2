import json
import os
import re
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import importlib  # noqa: E402
import matlab_literals  # noqa: E402
import value_formats  # noqa: E402
import variable_transfer_v2  # noqa: E402
for _module in (matlab_literals, value_formats, variable_transfer_v2):
    importlib.reload(_module)  # Rhino keeps old modules in memory
from variable_transfer_v2 import transfer_data, valid_name, valid_value  # noqa: E402

# Persistent folder (not %TEMP%, which Windows may clean up).
WORK_DIR = os.path.join(os.path.expanduser("~"), "HabSim")
os.makedirs(WORK_DIR, exist_ok=True)

DEFAULT_CONFIG_PATH = os.path.join(WORK_DIR, "transfer_config.json")
SOURCE_FILE = os.path.join(WORK_DIR, "grasshopper_variables.txt")
# The Grasshopper values exactly as received (before any conversion), so the GUI
# can show them and re-convert when the formats change.
RAW_FILE = os.path.join(WORK_DIR, "grasshopper_raw.json")
# The client's own value formats (1 | 2 | 3 -> [1 2 3] ...). Edited in the GUI.
FORMATS_FILE = os.path.join(WORK_DIR, "variable_formats.json")

MODE_TO_BACKEND = {
    "All Variables": "everything",
    "Include Variables": "include",
    "Exclude Variables": "exclude",
}

# The destination can be any of these. The type is read from the file extension.
#   matlab : .m                         values get your saved Value Formats
#   csv    : .csv                       plain values (see variable_transfer_v2, "CSV helpers")
#   json   : .json                      numbers/vectors only
#   text   : .py, .txt and anything     'name = value' lines
#            else
MATLAB_EXTENSIONS = (".m",)


def destination_kind(path):
    """'matlab', 'csv', 'json' or 'text' - decided by the file extension."""
    ext = os.path.splitext(str(path or ""))[1].lower()
    if ext in MATLAB_EXTENSIONS:
        return "matlab"
    if ext == ".csv":
        return "csv"
    if ext == ".json":
        return "json"
    return "text"


def uses_value_formats(dest_file):
    """Your saved Value Formats (1 | 2 | 3 -> [1 2 3] ...) are for MATLAB files only.

    With no destination given (None) they are used, as before.
    """
    return dest_file is None or destination_kind(dest_file) == "matlab"


def kind_label(dest_file):
    return {"matlab": "MATLAB", "csv": "CSV", "json": "JSON"}.get(
        destination_kind(dest_file), "text")


# ----------------------------------------------------------------- helpers
def values_per_name(values, n_names):
    """Turn whatever Grasshopper hands over into ONE item per name.

    Accepts a flat list (one value per name), a list of lists, or a Grasshopper
    data tree: one branch per variable. A branch with one item is a single value,
    a branch with several items is a vector; paths like {2;0},{2;1} (same first
    index) are the rows of a matrix. Values may be numbers, text, true/false or
    points.
    """
    if hasattr(values, "Branches"):                      # Grasshopper DataTree
        paths = [tuple(p.Indices) for p in values.Paths]
        branches = [list(br) for br in values.Branches]
        if len(branches) == 1 and n_names != 1 and len(branches[0]) == n_names:
            return list(branches[0])                     # plain list: 1 value per name
        groups = {}
        for path, br in zip(paths, branches):
            groups.setdefault(path[0] if path else 0, []).append(br)
        return [(grp[0][0] if len(grp[0]) == 1 else grp[0]) if len(grp) == 1
                else [list(b) for b in grp]
                for grp in groups.values()]
    if isinstance(values, str):
        values = [values]
    values = list(values or [])
    if any(isinstance(v, (list, tuple)) for v in values):
        return values
    if len(values) != n_names and n_names == 1:
        return [values]                                  # one name, many values: a vector
    return values


def plain_pairs(names, values):
    """GH names/values -> ({name: plain python value}, skipped). Nothing is converted yet."""
    names = [str(n).strip() for n in (names or [])]
    items = values_per_name(values, len(names))
    if len(names) != len(items):
        raise ValueError(
            "Names and Values must match: %d names but %d values/branches. "
            "For vectors give each variable its own branch (Values on Tree Access)."
            % (len(names), len(items)))
    plain, skipped = {}, []
    for n, item in zip(names, items):
        if not valid_name(n):
            skipped.append("%s (invalid name)" % (n or "<blank>"))
            continue
        try:
            plain[n] = value_formats.to_plain(item)
        except ValueError as e:
            skipped.append("%s (%s)" % (n, e))
    return plain, skipped


def _short(text, limit=60):
    text = str(text)
    return text if len(text) <= limit else text[:limit - 3] + "..."


def render_pairs(plain, rules=None):
    """{name: plain value} -> ({name: MATLAB text}, skipped, {name: format used})."""
    out, skipped, used = {}, [], {}
    for n, v in plain.items():
        try:
            text, rule_name = value_formats.convert(n, v, rules)
        except ValueError as e:
            skipped.append("%s (%s)" % (n, e))
            continue
        if not valid_value(text):                        # safety net, should not happen
            skipped.append("%s (could not be written as MATLAB: %s)" % (n, _short(text)))
            continue
        out[n] = text
        if rule_name:
            used[n] = rule_name
    return out, skipped, used


def clean_pairs(names, values):
    """GH names/values -> ({name: MATLAB text}, skipped), using the saved formats."""
    plain, skipped = plain_pairs(names, values)
    out, bad, _ = render_pairs(plain, value_formats.load_rules(FORMATS_FILE))
    return out, skipped + bad


def format_value(item):
    """One value -> MATLAB text (built-in rules only), or None if it can't be sent."""
    try:
        return value_formats.convert("x", item)[0]
    except ValueError:
        return None


def save_raw(plain, path=RAW_FILE):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(plain, f)
    except (OSError, TypeError, ValueError):
        pass


def load_raw(path=RAW_FILE):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def load_config(config_path):
    """Return the saved GUI state dict, or None if there isn't one."""
    if not config_path or not os.path.isfile(config_path):
        return None
    try:
        with open(config_path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def compose_renames(old_renames, changes):
    """Keep track of renames made in the config window.

    old_renames: {gh_name: name_currently_in_source_file}
    changes:     the GUI's source_changes {name_in_source_file: {"name":..,"value":..}}
    Returns the updated {gh_name: current_name} (only entries that differ).
    """
    current_to_gh = {cur: gh for gh, cur in (old_renames or {}).items()}
    renames = dict(old_renames or {})
    for current, change in (changes or {}).items():
        gh_name = current_to_gh.get(current, current)
        new_name = str(change["name"]).strip()
        if new_name != gh_name:
            renames[gh_name] = new_name
        else:
            renames.pop(gh_name, None)
    return renames


def render_source(renames=None, path=SOURCE_FILE, plain=None, skipped=None, dest_file=None):
    """Convert the Grasshopper values and write the source file.

    Lines look like  name = value;  (the program's internal text form). The saved
    Value Formats are applied only when the destination is a MATLAB file (or
    dest_file is None); for a .csv / .json / .py / .txt destination just the
    built-in conversions are used. Applies renames saved from the config window
    so saved links still match. Returns (pairs_written, skipped).
    """
    plain = load_raw() if plain is None else plain
    rules = value_formats.load_rules(FORMATS_FILE) if uses_value_formats(dest_file) else None
    texts, bad, _ = render_pairs(plain, rules)
    skipped = list(skipped or []) + bad
    renames = renames or {}
    final = {}
    for n, v in texts.items():
        new = renames.get(n, n)
        if new in final:
            raise ValueError("Two Grasshopper variables map to the name %r." % new)
        final[new] = v
    with open(path, "w", encoding="utf-8") as f:
        for n, v in final.items():
            f.write("%s = %s;\n" % (n, v))
    return final, skipped


def write_source_file(names, values, renames=None, path=SOURCE_FILE,
                      dest_file=None, overrides=None):
    """Save the live GH values, apply multi-run overrides and write the source file.

    Returns (pairs_written, skipped_names).
    """
    plain, skipped = plain_pairs(names, values)

    # Replace the original GH values with the current iteration's values.
    if overrides:
        plain.update(overrides)

    save_raw(plain)
    return render_source(renames, path, plain, skipped, dest_file)


def _check_dest(dest_file):
    if not dest_file or not os.path.isfile(dest_file):
        raise ValueError("Destination file not found: %s" % dest_file)


def _same_file(a, b):
    return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))



def _clean_env():
    """Environment for launching an EXTERNAL python from inside Rhino.

    Rhino sets PYTHONHOME / PYTHONPATH etc. for its own embedded Python. If
    they are passed on, the external python loads Rhino's standard library and
    crashes (e.g. 'SRE module mismatch'). Remove them.
    """
    env = dict(os.environ)
    for key in list(env):
        if key.upper() in ("PYTHONHOME", "PYTHONPATH", "PYTHONEXECUTABLE",
                           "PYTHONSTARTUP", "PYTHONUSERBASE", "PYTHONNOUSERSITE",
                           "__PYVENV_LAUNCHER__", "VIRTUAL_ENV"):
            env.pop(key)
    return env

LAST_STATUS_FILE = os.path.join(WORK_DIR, "last_gui_status.txt")


def save_last_status(text):
    """Remember what the last Open press did (a Button resets right after)."""
    try:
        with open(LAST_STATUS_FILE, "w", encoding="utf-8") as f:
            f.write(text)
    except OSError:
        pass


def load_last_status():
    try:
        with open(LAST_STATUS_FILE, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


# --------------------------------------------------------------------- GUI
def launch_config_gui(names, values, dest_file, python_exe="python",
                      config_path=DEFAULT_CONFIG_PATH):
    """Open the full Transfer window in a separate process (does not block GH).

    Source = the live GH variables, destination = dest_file (a .m or .csv file,
    or any other file with  name = value  lines).
    """
    _check_dest(dest_file)
    config = load_config(config_path) or {}
    final, skipped = write_source_file(names, values, config.get("renames"),
                                       dest_file=dest_file)
    if not final:
        raise ValueError("No valid GH variables to configure. Rejected: %s"
                         % (", ".join(skipped) or "none were supplied"))
    gui_script = os.path.join(HERE, "gh_gui.py")
    python_exe = python_exe or "python"

    # Send the GUI's errors to a log file instead of a console window that
    # vanishes, and hide the console on Windows.
    log_path = os.path.join(WORK_DIR, "gui_error.log")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    with open(log_path, "w", encoding="utf-8") as log:
        try:
            proc = subprocess.Popen(
                [python_exe, gui_script, SOURCE_FILE,
                 os.path.abspath(dest_file), config_path],
                stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                cwd=HERE, creationflags=flags, env=_clean_env())
        except OSError as e:
            raise RuntimeError(
                "Could not start Python (%r): %s. Put the full path to python.exe "
                "in the PythonExe input." % (python_exe, e))

    # If it dies within a couple of seconds it crashed: report why.
    try:
        proc.wait(timeout=2.5)
    except subprocess.TimeoutExpired:
        return config_path  # still running = the window is open
    with open(log_path, encoding="utf-8", errors="replace") as f:
        detail = f.read().strip()
    hint = ""
    if "tkinter" in detail:
        hint = (" -> This Python has no tkinter. Reinstall Python from python.org "
                "with 'tcl/tk and IDLE' ticked, or point PythonExe at one that has it.")
    elif not detail:
        hint = (" -> No error text. 'python' may be the Microsoft Store shortcut; "
                "put the full path to python.exe in PythonExe.")
    raise RuntimeError("GUI closed immediately (exit code %s). %s%s"
                       % (proc.returncode, detail[-1200:], hint))


# ---------------------------------------------------------------- transfer
def matlab_is_running(matlab_file, max_age=3600):
    """True while a Run MATLAB job is using this file (ignores a stale lock)."""
    lock = os.path.abspath(matlab_file) + ".running"
    try:
        return time.time() - os.path.getmtime(lock) < max_age
    except OSError:
        return False


def transfer(names, values, dest_file, config_path=None, overrides=None):
    """GH variables -> destination file. Returns (report_lines, skipped_names).

    The destination is usually a MATLAB .m file or a .csv file. For a .m file
    your saved Value Formats are applied; for any other file type the values are
    written as plain values.
    """
    _check_dest(dest_file)
    if matlab_is_running(dest_file):
        raise RuntimeError("MATLAB is still running this file. Wait for Run MATLAB "
                           "to finish (or Cancel it) before transferring.")
    config = load_config(config_path)
    notes = []
    no_config_reason = None            # why the saved GUI config is not being used

    if not config_path:
        no_config_reason = "the Config input of Transfer Variables MATLAB is not connected (wire GUI Config's Config output to it)"
    elif config is None:
        no_config_reason = "no saved config found at %s (press Open on GUI Config, then OK)" % config_path

    # A saved config only applies to the destination file it was made for.
    if config and config.get("destination") and not _same_file(
            config["destination"], dest_file):
        no_config_reason = ("the saved config was made for a different destination file (%s)"
                            % os.path.basename(config["destination"]))
        config = None
    elif config and not config.get("configured"):
        no_config_reason = ("the GUI configuration was never saved (open the GUI and click OK "
                            "in the configuration window)")

    renames = (config or {}).get("renames")
    final, skipped = write_source_file(
        names, values, renames,
        dest_file=dest_file,
        overrides=overrides
    )

    if not final:
        raise ValueError("No valid GH variables were supplied. Rejected: %s"
                         % (", ".join(skipped) or "none were supplied"))

    if config and config.get("configured"):
        mode_name = config.get("mode", "All Variables")
        mode = MODE_TO_BACKEND.get(mode_name, "everything")
        selected = config.get("selected", [])
        mappings = config.get("mappings", {})
        if mode == "include" and not selected:
            raise ValueError("The saved config has no variables selected. "
                             "Open the GUI and save a configuration.")
        result = transfer_data(SOURCE_FILE, dest_file, mode, selected,
                               mappings=mappings)
        notes.append("note: used the saved GUI config (%s, %d link(s))"
                     % (mode_name, len(mappings)))
    else:
        mode_name = "All Variables"
        selected = []
        # No saved config: overwrite same-name variables, ignore everything else.
        result = transfer_data(SOURCE_FILE, dest_file, "everything")
        notes.append("note: saved GUI config NOT used - %s. Used same-name matching instead."
                     % (no_config_reason or "no configuration was saved"))

    # Same history log the standalone GUI writes (optional, never fatal).
    try:
        from history import record_transfer
        record_transfer(SOURCE_FILE, dest_file, mode_name, selected,
                        result["transferred"], result["changes"],
                        result["mappings"])
    except Exception as e:  # tkinter missing, read-only folder, ...
        notes.append("note: history not recorded (%s)" % e)

    lines = ["%s -> %s : %s -> %s" % (c["source"], d, _short(c["before"]), _short(c["after"]))
             for d, c in result["changes"].items()]
    if not lines:
        lines = ["(no values changed)"]
    for m in result["missing_in_destination"]:
        lines.append("warning: '%s' not found in the %s file" % (m, kind_label(dest_file)))
    return lines + notes, skipped


# ------------------------------------------------------------------ MATLAB
# The run itself lives in run_matlab_gh.py (your run-MATLAB script, made
# reusable). It can run inside this process, or as its own python process.
RUN_SCRIPT = os.path.join(HERE, "run_matlab_gh.py")

_LINE = re.compile(r"^\s*([A-Za-z_]\w*)\s*=\s*(.+?)\s*$")
_SCALAR = re.compile(r"^[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?$")


def run_matlab(matlab_file, matlab_exe="matlab", timeout=600, python_exe=None):
    """Run the .m file via run_matlab_gh.py. Returns (names, values).

    python_exe=None  -> run in this process (no extra python needed)
    python_exe=path  -> run run_matlab_gh.py as a separate python process
    """
    if not matlab_file or not os.path.isfile(matlab_file):
        raise ValueError("MATLAB file not found: %s" % matlab_file)
    matlab_file = os.path.abspath(matlab_file)

    if python_exe:
        proc = subprocess.run([python_exe, RUN_SCRIPT, matlab_file, matlab_exe],
                              capture_output=True, text=True, timeout=timeout + 30,
                              env=_clean_env())
        if proc.returncode != 0:
            raise RuntimeError((proc.stderr or proc.stdout).strip()[-1500:])
        out_file = proc.stdout.strip().splitlines()[-1]
    else:
        import run_matlab_gh
        out_file = run_matlab_gh.run(matlab_file, matlab_exe, timeout)
    return read_results(out_file)


class MatlabJob(object):
    """Runs MATLAB on a background thread so Grasshopper stays responsive.

    state: 'running' -> 'done' | 'error' | 'cancelled'
    After 'done': .names / .values.  After 'error': .error (text).
    on_done() is called (from the background thread) when it finishes - the
    Grasshopper block uses it to ask the component to recompute.
    """

    def __init__(self, matlab_file, matlab_exe="matlab", timeout=600, on_done=None):
        self.matlab_file = os.path.abspath(matlab_file)
        self.matlab_exe = matlab_exe or "matlab"
        self.timeout = timeout
        self.on_done = on_done
        self.state = "running"
        self.names, self.values, self.error = [], [], ""
        self.started = time.time()
        self.finished = None
        self._proc = None
        self._cancelled = False
        self._thread = threading.Thread(target=self._work, name="habsim-matlab")
        self._thread.daemon = True

    @property
    def running(self):
        return self.state == "running"

    @property
    def elapsed(self):
        return (self.finished or time.time()) - self.started

    def start(self):
        self._thread.start()
        return self

    def cancel(self):
        self._cancelled = True
        if self._proc is not None:
            import run_matlab_gh
            run_matlab_gh.kill_tree(self._proc)

    def _set_proc(self, proc):
        self._proc = proc
        if self._cancelled:             # cancelled before MATLAB had started
            import run_matlab_gh
            run_matlab_gh.kill_tree(proc)

    def _work(self):
        try:
            import run_matlab_gh
            out_file = run_matlab_gh.run(self.matlab_file, self.matlab_exe,
                                         self.timeout, on_start=self._set_proc)
            self.names, self.values = read_results(out_file)
            self.state = "done"
        except Exception as e:
            if self._cancelled:
                self.state, self.error = "cancelled", "Cancelled."
            else:
                self.state, self.error = "error", str(e)
        finally:
            self.finished = time.time()
            if self.on_done:
                try:
                    self.on_done()
                except Exception:
                    pass


def _array_values(x):
    """JSON array -> list of floats, or list of lists (matrix). null -> NaN."""
    def f(v):
        return float("nan") if v is None else float(v)
    if x and all(isinstance(r, list) for r in x):
        return [[f(v) for v in r] for r in x]
    return [f(v) for v in x]


def to_branches(values):
    """Values from run_matlab -> [(path, [items])] for building a Grasshopper tree.

    scalar -> {i} one item;  vector -> {i} n items;  matrix -> {i;row} per row.
    """
    out = []
    for i, v in enumerate(values):
        if isinstance(v, list) and v and isinstance(v[0], list):
            for r, row in enumerate(v):
                out.append(((i, r), list(row)))
        elif isinstance(v, list):
            out.append(((i,), list(v)))
        else:
            out.append(((i,), [v]))
    return out


def flatten_json(obj, prefix="", out=None):
    """{'meteorite': {'IL': 1}} -> {'meteorite.IL': 1.0}. Returns an ordered dict."""
    out = {} if out is None else out
    if isinstance(obj, dict):
        for key, val in obj.items():
            flatten_json(val, prefix + "." + key if prefix else key, out)
    elif isinstance(obj, list) and obj and all(isinstance(i, dict) for i in obj):
        for i, item in enumerate(obj, 1):           # struct array
            flatten_json(item, "%s(%d)" % (prefix, i), out)
    elif isinstance(obj, list):
        out[prefix] = _array_values(obj)
    elif isinstance(obj, bool):
        out[prefix] = 1.0 if obj else 0.0
    elif isinstance(obj, (int, float)):
        out[prefix] = float(obj)
    elif obj is None:
        out[prefix] = float("nan")
    else:
        out[prefix] = str(obj)
    return out


def read_results(out_file):
    """Read MATLAB's exported variables.

    Prefers matlab_output_variables.json (handles structs like meteorite.IL);
    falls back to the .txt file."""
    json_file = os.path.splitext(out_file)[0] + ".json"
    if os.path.isfile(json_file):
        try:
            with open(json_file, encoding="utf-8") as f:
                flat = flatten_json(json.load(f))
            if flat:
                return list(flat.keys()), list(flat.values())
        except (OSError, ValueError):
            pass  # fall back to the text file
    return _read_txt_results(out_file)


def _parse_text_value(raw):
    """'5' -> 5.0 ; '[1 2 3]' -> [1.0, 2.0, 3.0] ; '[1 2;3 4]' -> [[1,2],[3,4]]."""
    if _SCALAR.match(raw):
        return float(raw)
    if raw.startswith("[") and raw.endswith("]"):
        try:
            rows = [[float(t) for t in r.replace(",", " ").split()]
                    for r in raw[1:-1].split(";")]
            return rows[0] if len(rows) == 1 else rows
        except ValueError:
            pass
    return raw


def _read_txt_results(out_file):
    """Parse 'name = value' lines. Scalars become floats, everything else stays text."""
    if not os.path.isfile(out_file):
        raise RuntimeError("MATLAB finished but wrote no output file.")
    names, values = [], []
    with open(out_file, encoding="utf-8") as f:
        for line in f:
            m = _LINE.match(line)
            if not m:
                continue
            names.append(m.group(1))
            raw = m.group(2)
            values.append(_parse_text_value(raw))
    return names, values
