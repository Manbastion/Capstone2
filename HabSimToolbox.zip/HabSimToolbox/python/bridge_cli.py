"""Command-line bridge used by the HabSim Grasshopper plugin (HabSimToolbox.gha).

The C# components call:   python bridge_cli.py <command>
with a JSON request on stdin. The reply is written to stdout as tab-separated
lines:  <key>\t<value>   (newline / tab / backslash inside a value are escaped
as \\n \\t \\\\). Keys may repeat (e.g. 'report').

This file contains the logic that used to live in the pasted Grasshopper Python
scripts (grasshopper_blocks/*.py); everything else is the unchanged backend.
"""
import json
import os
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import gh_bridge  # noqa: E402
import multirun  # noqa: E402


# ------------------------------------------------------------------ helpers
class _Path(object):
    def __init__(self, indices):
        self.Indices = tuple(int(i) for i in indices)


class Tree(object):
    """Looks like a Grasshopper DataTree to the existing backend (Paths/Branches)."""

    def __init__(self, paths, branches):
        self.Paths = [_Path(p) for p in paths]
        self.Branches = [list(b) for b in branches]


def tree_from_json(obj):
    if obj is None:
        return None
    return Tree(obj.get("paths", []), obj.get("branches", []))


def _esc(text):
    return (str(text).replace("\\", "\\\\").replace("\t", "\\t")
            .replace("\r", "").replace("\n", "\\n"))


class Reply(object):
    def __init__(self):
        self.lines = []

    def add(self, key, value=""):
        if isinstance(value, bool):
            value = "1" if value else "0"
        self.lines.append("%s\t%s" % (key, _esc(value)))
        return self

    def text(self):
        return "\n".join(self.lines) + "\n"


def _python_exe(req):
    return req.get("python_exe") or sys.executable or "python"


# ----------------------------------------------------------------- commands
def cmd_transfer_matlab(req, out):
    names = req.get("names") or []
    values = tree_from_json(req.get("values"))
    matlab_file = req.get("matlab_file") or ""
    try:
        if not matlab_file or not os.path.isfile(matlab_file):
            raise ValueError("MatlabFile must point to an existing MATLAB script.")
        state = multirun.load_state()
        overrides = multirun.current_overrides(state) if state else None
        report, skipped = gh_bridge.transfer(
            names, values, matlab_file, req.get("config") or None, overrides=overrides)
        status = "Variable transfer complete. Trigger sent."
        if skipped:
            status += " Skipped: " + "; ".join(skipped)
        out.add("trigger", True).add("status", status)
        for line in report:
            out.add("report", line)
    except Exception as error:
        multirun.fail_transfer(error)
        out.add("trigger", False).add("error", True).add("status", "ERROR: %s" % error)


def cmd_transfer_csv(req, out):
    import csv_cells
    names = req.get("names") or []
    values = tree_from_json(req.get("values"))
    csv_file = req.get("csv_file") or ""
    mapping = req.get("mapping") or []
    try:
        if not csv_file or not os.path.isfile(csv_file):
            raise ValueError("CSVFile must point to an existing CSV file.")
        plain, skipped = gh_bridge.plain_pairs(names, values)
        try:
            state = multirun.load_state()
            overrides = multirun.current_overrides(state) if state else None
        except (ImportError, OSError, ValueError):
            overrides = None
        if overrides:
            plain.update(overrides)

        if req.get("trigger"):
            report, _ = csv_cells.transfer_cells(csv_file, mapping, plain)
            count = len([l for l in report if not l.startswith("note:")])
            status = "CSV updated: %d cell(s). Trigger sent." % count
            if skipped:
                status += " Skipped variables: " + "; ".join(skipped)
            out.add("trigger", True)
        else:
            report = csv_cells.preview(csv_file, mapping, plain)
            status = "Mapping check complete: %d cell(s) found." % len(report)
            out.add("trigger", False)
        out.add("status", status)
        for line in report:
            out.add("report", line)
    except Exception as error:
        # Only a real (triggered) transfer should abort a running batch.
        if req.get("trigger"):
            multirun.fail_transfer(error)
        out.add("trigger", False).add("error", True).add("status", "ERROR: %s" % error)


def cmd_config_open(req, out):
    config_path = gh_bridge.DEFAULT_CONFIG_PATH
    try:
        matlab_file = req.get("matlab_file") or ""
        if not matlab_file or not os.path.isfile(matlab_file):
            raise ValueError("MatlabFile must point to an existing MATLAB script.")
        names = req.get("names") or []
        values = tree_from_json(req.get("values"))
        if not names or values is None:
            raise ValueError("Connect Names and Values before opening the configuration window.")
        gh_bridge.launch_config_gui(names, values, matlab_file, _python_exe(req), config_path)
        status = ("GUI opened. Link your variables, click OK in the configuration window, "
                  "then recompute this component to use the saved configuration.")
        gh_bridge.save_last_status(status)
        out.add("status", status)
    except Exception as error:
        status = "ERROR: %s" % error
        try:
            gh_bridge.save_last_status(status)
        except Exception:
            pass
        out.add("error", True).add("status", status)


def cmd_multirun_open(req, out):
    import multirun_entwine
    try:
        names = req.get("names") or []
        plain, skipped = gh_bridge.plain_pairs(names, tree_from_json(req.get("values")))
        if skipped:
            raise ValueError("Some connected baseline variables cannot be used: %s"
                             % "; ".join(skipped))
        if not plain:
            raise ValueError("Connect at least one variable through Names and Values.")

        ent_names = tree_from_json(req.get("ent_names"))
        ent_values = tree_from_json(req.get("ent_values"))
        if (ent_names is None) != (ent_values is None):
            raise ValueError("EntwinedNames and EntwinedValues must both be connected.")

        overrides = []
        if ent_names is not None:
            overrides = multirun_entwine.entwine_iteration_overrides(
                ent_names, ent_values, plain, gh_bridge.plain_pairs)

        for pair in req.get("pairs") or []:
            i = int(pair["i"])
            n_label, v_label = "Names_%d" % i, "Values_%d" % i
            pair_names = pair.get("names")
            pair_values = tree_from_json(pair.get("values"))
            if (pair_names is None) != (pair_values is None):
                raise ValueError("%s and %s must both be connected." % (n_label, v_label))
            pairs, pair_skipped = gh_bridge.plain_pairs(pair_names, pair_values)
            if pair_skipped:
                raise ValueError("Invalid variables in %s / %s: %s"
                                 % (n_label, v_label, "; ".join(pair_skipped)))
            if not pairs:
                raise ValueError("%s and %s are connected, but contain no valid variables."
                                 % (n_label, v_label))
            unknown = [n for n in pairs if n not in plain]
            if unknown:
                raise ValueError("%s contains variables not present in the baseline Names "
                                 "input: %s" % (n_label, ", ".join(unknown)))
            while len(overrides) < i:
                overrides.append({})
            existing = overrides[i - 1]
            dup = [n for n in pairs if n in existing]
            if dup:
                raise ValueError("%s duplicates variables already supplied for iteration %d: %s"
                                 % (n_label, i, ", ".join(dup)))
            existing.update(pairs)

        while overrides and not overrides[-1]:
            overrides.pop()

        multirun.launch_gui(list(plain.keys()), list(plain.values()), _python_exe(req),
                            iteration_overrides=overrides,
                            save_path=(req.get("save_path") or None))
        out.add("status", "Multi-run editor opened. Enter the values and click Run iterations.")
    except Exception as error:
        out.add("error", True).add("status", "ERROR: %s" % error)


def cmd_multirun_step(req, out):
    """One controller solve: handle Stop, advance queued -> running, pulse Trigger."""
    trigger, iteration, status = False, 0, ""
    if req.get("stop"):
        if multirun.request_stop():
            status = ("Stop requested. The current MATLAB iteration will finish, "
                      "then the batch will stop.")
    state = multirun.load_state()
    if state:
        st = state.get("status")
        index = int(state.get("index", 0))
        total = len(state.get("iterations", []))
        iteration = min(index + 1, total) if total else 0

        if st == "queued":
            state["status"] = "running"
            state["phase"] = "pulse_on"
            state["iteration_done"] = False
            state["pulse_off_done"] = False
            multirun.save_state(state)
            st = "running"

        if st == "running":
            if state.get("phase") == "pulse_on":
                if state.get("stop_requested"):
                    state["status"] = "cancelled"
                    state["phase"] = "cancelled"
                    state["error"] = "Stopped before iteration started."
                    multirun.save_state(state)
                    status = state["error"]
                else:
                    trigger = True
                    state["iteration_started_at"] = datetime.now().isoformat(timespec="seconds")
                    status = "Starting iteration %d of %d." % (index + 1, total)
                    state["phase"] = "waiting"
                    state["pulse_off_done"] = False
                    multirun.save_state(state)
            elif not status:
                status = "Running iteration %d of %d." % (index + 1, total)
        elif st == "complete":
            status = "Complete. Successfully ran %d iteration(s)." % total
            iteration = total
        elif st in ("error", "cancelled"):
            status = state.get("error") or ("Multi-run %s." % st)
        else:
            status = "Multi-run is %s." % st
    out.add("trigger", trigger).add("iteration", iteration).add("status", status)


def cmd_multirun_info(req, out):
    state = multirun.load_state()
    if not state:
        out.add("status", "")
        return
    out.add("status", state.get("status") or "")
    out.add("index", int(state.get("index", 0)))
    out.add("total", len(state.get("iterations", [])))
    out.add("error", state.get("error") or "")


def cmd_multirun_marker(req, out):
    state = multirun.load_state()
    if state is not None:
        state["matlab_output_marker"] = os.path.join(
            os.path.dirname(os.path.abspath(req["matlab_file"])), "matlab_output_folder.txt")
        multirun.save_state(state)


def cmd_multirun_finish(req, out):
    out.add("advanced", bool(multirun.finish_iteration(int(req.get("code", 1)))))


def cmd_multirun_fail(req, out):
    multirun.fail_transfer(req.get("message") or "unknown error")


def cmd_ping(req, out):
    out.add("python", sys.version.split()[0]).add("executable", sys.executable)
    try:
        import tkinter  # noqa: F401
        out.add("tkinter", True)
    except Exception:
        out.add("tkinter", False)


COMMANDS = {
    "transfer-matlab": cmd_transfer_matlab,
    "transfer-csv": cmd_transfer_csv,
    "config-open": cmd_config_open,
    "multirun-open": cmd_multirun_open,
    "multirun-step": cmd_multirun_step,
    "multirun-info": cmd_multirun_info,
    "multirun-marker": cmd_multirun_marker,
    "multirun-finish": cmd_multirun_finish,
    "multirun-fail": cmd_multirun_fail,
    "ping": cmd_ping,
}


def main(argv):
    if len(argv) < 2 or argv[1] not in COMMANDS:
        sys.stderr.write("usage: bridge_cli.py <%s>\n" % "|".join(COMMANDS))
        return 2
    raw = sys.stdin.buffer.read().decode("utf-8") if not sys.stdin.isatty() else ""
    req = json.loads(raw) if raw.strip() else {}

    real_stdout = sys.stdout
    sys.stdout = sys.stderr          # stray prints must not corrupt the reply
    out = Reply()
    try:
        COMMANDS[argv[1]](req, out)
    except Exception as error:       # last-resort safety net
        out.add("error", True).add("status", "ERROR: %s" % error)
    finally:
        sys.stdout = real_stdout
    data = out.text().encode("utf-8")
    sys.stdout.buffer.write(data)
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
