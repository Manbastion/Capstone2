"""Window icons for the HabSim Tkinter windows (top-left corner of the title bar).

Icons live in python/icons/: <name>.ico (Windows) and <name>_256.png (everything else).
Never raises: a missing icon must not stop a window from opening.
"""
import os
import sys

ICON_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons")


def icon_path(name, kind="png"):
    path = os.path.join(ICON_DIR, name + (".ico" if kind == "ico" else "_256.png"))
    return path if os.path.isfile(path) else None


def apply_icon(window, name):
    """Set the title-bar icon of a Tk or Toplevel window. Returns True if one was set."""
    done = False
    try:
        ico = icon_path(name, "ico")
        if sys.platform == "win32" and ico:
            window.iconbitmap(ico)
            done = True
    except Exception:
        pass
    if not done:
        try:
            png = icon_path(name)
            if png:
                photo = window.tk.call("image", "create", "photo", "-file", png)
                window.tk.call("wm", "iconphoto", window._w, photo)
                window._habsim_icon = photo  # keep the image alive
                done = True
        except Exception:
            pass
    return done


def load_photo(window, name, shrink=1):
    """A PhotoImage of the icon for use inside a window (kept alive on the window)."""
    try:
        import tkinter as tk
        png = icon_path(name)
        if not png:
            return None
        photo = tk.PhotoImage(master=window, file=png)
        if shrink > 1:
            photo = photo.subsample(shrink, shrink)
        window.__dict__.setdefault("_habsim_photos", []).append(photo)
        return photo
    except Exception:
        return None
