"""HabSim notification pop-up (Tkinter). Runs as its own small process.

Usage: habsim_popup.py <base64 of JSON [title, body, sound, seconds]>
Exits with 0 when shown, 3 if Tkinter cannot show it (the caller then falls back).
Shows the notification icon in the title bar (top-left) and inside the window.
"""
import base64
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


def show(title, body, sound=True, seconds=15):
    import tkinter as tk
    from tkinter import ttk
    from habsim_icons import apply_icon, load_photo

    root = tk.Tk()
    root.title("HabSim")
    apply_icon(root, "notification")
    root.resizable(False, False)
    try:
        root.attributes("-topmost", True)
    except Exception:
        pass

    frame = ttk.Frame(root, padding=14)
    frame.pack(fill="both", expand=True)
    picture = load_photo(root, "notification", shrink=4)  # 256 px -> 64 px
    if picture is not None:
        ttk.Label(frame, image=picture).grid(row=0, column=0, rowspan=2, sticky="n", padx=(0, 12))
    ttk.Label(frame, text=title, font=("TkDefaultFont", 11, "bold"), wraplength=320,
              justify="left").grid(row=0, column=1, sticky="w")
    ttk.Label(frame, text=body, wraplength=320, justify="left").grid(row=1, column=1, sticky="w", pady=(4, 0))
    ttk.Button(frame, text="OK", command=root.destroy).grid(row=2, column=1, sticky="e", pady=(12, 0))

    root.update_idletasks()
    w, h = root.winfo_reqwidth(), root.winfo_reqheight()
    x = max(0, root.winfo_screenwidth() - w - 24)
    y = max(0, root.winfo_screenheight() - h - 72)  # clear of the Windows taskbar
    root.geometry("%dx%d+%d+%d" % (w, h, x, y))
    root.bind("<Return>", lambda _e: root.destroy())
    root.bind("<Escape>", lambda _e: root.destroy())
    root.after(max(1, int(seconds)) * 1000, root.destroy)

    if sound and sys.platform == "win32":
        try:
            import winsound
            winsound.MessageBeep(winsound.MB_ICONASTERISK)
        except Exception:
            pass
    try:
        root.lift()
        root.focus_force()
    except Exception:
        pass
    root.mainloop()


def main(argv):
    try:
        title, body, sound, seconds = json.loads(base64.b64decode(argv[1]).decode("utf-8"))
        show(str(title), str(body), bool(sound), seconds)
        return 0
    except Exception:
        return 3


if __name__ == "__main__":
    sys.exit(main(sys.argv))
